extends RefCounted
class_name PalagosData

# Values are based on the browser prototype v0.5 and are adjusted in Godot independently.
const CLASSES = {
    "krieger": {"name":"Krieger", "hp":138, "damage":28, "range":3.6, "cast":0.0, "color":Color("b66a53"), "basic":"Klingenhieb", "first":"Wirbelsturm", "second":"Kriegsschrei", "costs":[0,26,28], "cooldowns":[1.65,8.0,15.0], "region":"Eisenklamm", "theme":Color("6c725e"), "talents":["Klingenmeister", "Sturmgewalt", "Eiserner Wille"]},
    "jaeger": {"name":"Jäger", "hp":108, "damage":26, "range":17.0, "cast":0.0, "color":Color("719e67"), "basic":"Jagdpfeil", "first":"Pfeilhagel", "second":"Falkenfokus", "costs":[0,26,25], "cooldowns":[1.22,8.0,14.0], "region":"Grünwald", "theme":Color("44775b"), "talents":["Scharfschütze", "Pfeilmeister", "Adlerauge"]},
    "magier": {"name":"Magier", "hp":92, "damage":30, "range":17.0, "cast":1.65, "color":Color("6a9ecb"), "basic":"Arkanstoß", "first":"Feuerball", "second":"Frostnova", "costs":[10,30,32], "cooldowns":[0.25,8.0,14.0], "region":"Astralhain", "theme":Color("515d87"), "talents":["Arkanes Wissen", "Flammenkunst", "Frostseele"]},
    "priester": {"name":"Priester", "hp":102, "damage":26, "range":17.0, "cast":1.55, "color":Color("e4c994"), "basic":"Lichtfunke", "first":"Heilige Welle", "second":"Segen", "costs":[10,29,32], "cooldowns":[0.25,9.0,16.0], "region":"Lichtwacht", "theme":Color("918675"), "talents":["Lichtbringer", "Geweihte Welle", "Segensmacht"]},
    "druide": {"name":"Druide", "hp":116, "damage":28, "range":17.0, "cast":1.7, "color":Color("69a87a"), "basic":"Dornenwurf", "first":"Wurzelgriff", "second":"Natursegen", "costs":[10,28,30], "cooldowns":[0.25,9.0,16.0], "region":"Wurzelmeer", "theme":Color("57735e"), "talents":["Dornenherz", "Wurzelmacht", "Uralte Form"]},
    "paladin": {"name":"Paladin", "hp":132, "damage":21, "range":3.6, "cast":0.0, "color":Color("e7ba5c"), "basic":"Richtschlag", "first":"Weihe", "second":"Göttlicher Schild", "costs":[0,28,34], "cooldowns":[1.65,9.0,17.0], "region":"Sonnenfeste", "theme":Color("8f8062"), "talents":["Richtspruch", "Lichtflamme", "Schild des Lichts"]}
}

const ORDER = ["krieger", "jaeger", "magier", "priester", "druide", "paladin"]
const REGION_INTROS = {
    "krieger": "Schütze die Bergwacht und halte den Vormarsch der Kernbrut auf.",
    "jaeger": "Suche die verdorbenen Fährten am Rand des Grünwalds.",
    "magier": "Untersuche die arkane Verseuchung nahe der Sternenwarte.",
    "priester": "Bewahre das Licht der letzten Heiligtümer.",
    "druide": "Heile die verletzten Wurzeln des Planeten Palagos.",
    "paladin": "Verteidige die Sonnenfeste gegen die außerirdische Verderbnis."
}

# Three functional introductory quests per class. A larger, hand-written quest chain
# (~50 quests per starting region) is deliberately a later production milestone.
static func quests_for(class_id: String) -> Array[Dictionary]:
    var label: String = CLASSES[class_id]["region"]
    return [
        {"title":"Ein Ruf aus " + label, "desc":"Besiege 3 Kernbrut-Kreaturen und melde dich bei der Wache.", "count":3, "xp":90},
        {"title":"Die erste Verderbnis", "desc":"Besiege 5 Kernbrut-Kreaturen, um das Lager zu sichern.", "count":5, "xp":140},
        {"title":"Die Wächterprobe", "desc":"Besiege 7 Kernbrut-Kreaturen. Weitere Quests folgen in künftigen Versionen.", "count":7, "xp":190}
    ]
