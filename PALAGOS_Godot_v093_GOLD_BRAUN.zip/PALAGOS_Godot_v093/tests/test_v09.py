from pathlib import Path
import re, unittest
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=(ROOT/'scripts/main.gd').read_text()
class TestPalagosGraphics(unittest.TestCase):
    def test_six_classes_and_progression(self):
        text=(ROOT/'scripts/game_data.gd').read_text()
        for klass in ['krieger','jaeger','magier','priester','druide','paladin']:
            self.assertIn('"'+klass+'"',text)
        for requirement in ['while level < 20','_setup_music','_setup_system_panels','_make_class_landmark','_build_vendors']:
            self.assertIn(requirement,SCRIPT)
    def test_terrain_and_optimized_geometry(self):
        for method in ['_terrain_height','_make_ground','_make_forest','_make_village','_make_house','_hut_roof','_instanced_mesh']:
            self.assertIn('func '+method+'(',SCRIPT)
        for term in ['MultiMesh.new()','SurfaceTool.new()','sun.shadow_enabled','VertexColor']:
            if term!='VertexColor': self.assertIn(term,SCRIPT)
    def test_all_textures(self):
        for path in ['terrain_grass.png','terrain_path.png','rock_moss.png','bark_worn.png','leaf_cluster.png','village_plaster.png','roof_shingles.png','title_palagos.png']:
            self.assertGreater((ROOT/'assets'/path).stat().st_size,20000,path)
    def test_preview_is_explicit_texture(self):
        for phrase in ['preview_container.add_child(creator_preview)','creator_preview.own_world_3d = true','creator_preview.render_target_update_mode = SubViewport.UPDATE_ALWAYS','preview_root.rotation.y += delta','_update_preview()']:
            self.assertIn(phrase,SCRIPT)
    def test_camera_is_not_mirrored(self):
        self.assertIn('camera_yaw += delta_motion.x * (0.006 if camera_invert_x else -0.006)', SCRIPT)
        self.assertIn('camera_pitch = clampf(camera_pitch + delta_motion.y * (0.003 if camera_invert_y else -0.003)',SCRIPT)
        self.assertEqual(SCRIPT.count('_apply_camera_drag(event.relative)'),1)
        self.assertEqual(SCRIPT.count('_apply_camera_drag(delta_motion)'),1)
        for method in ['_load_camera_settings','_save_camera_settings','_set_camera_invert_x','_set_camera_invert_y']:
            self.assertIn('func '+method+'(',SCRIPT)
    def test_no_duplicate_scripts(self):
        fns=re.findall(r'^func (\w+)\(',SCRIPT,re.M)
        self.assertEqual(len(fns),len(set(fns)))
        self.assertNotIn('PrimitiveMesh3D',SCRIPT)
        self.assertIn('textures/vram_compression/import_etc2_astc=true',(ROOT/'project.godot').read_text())
if __name__=='__main__':unittest.main()
