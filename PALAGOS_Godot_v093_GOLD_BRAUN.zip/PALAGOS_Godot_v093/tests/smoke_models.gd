extends SceneTree

# Godot headless regression: real GLTF model in preview and playable classes.
func _initialize() -> void:
    call_deferred("_run")

func _fail(reason: String) -> void:
    push_error("MODEL_SMOKE_FAIL: " + reason)
    quit(1)

func _run() -> void:
    var scene: PackedScene = load("res://scenes/Main.tscn") as PackedScene
    if scene == null:
        _fail("Main scene did not load")
        return
    var game: Node = scene.instantiate()
    root.add_child(game)
    await process_frame
    game.call("_show_creator")
    await process_frame
    var viewport: SubViewport = game.get("creator_preview") as SubViewport
    if viewport == null:
        _fail("Character preview missing")
        return
    var preview_model: Node = viewport.find_child("Quaternius_*", true, false)
    if preview_model == null:
        _fail("3D GLTF model not visible in preview scene tree")
        return
    if viewport.get_camera_3d() == null:
        _fail("Preview has no 3D camera")
        return
    var hero_classes: Array[String] = ["krieger", "jaeger", "magier", "priester", "druide", "paladin"]
    for hero_class in hero_classes:
        game.call("_start_game", hero_class)
        await process_frame
        var hero: Node3D = game.get("hero") as Node3D
        if hero == null or hero.find_child("Quaternius_*", true, false) == null:
            _fail("Imported 3D model missing for " + hero_class)
            return
        var ap: AnimationPlayer = game.get("imported_hero_animation") as AnimationPlayer
        if ap == null or ap.get_animation_list().is_empty():
            _fail("Imported animation library missing for " + hero_class)
            return
    print("PALAGOS_093_MODELS_PASS: six classes, imported rigs, animations, and class preview")
    quit(0)
