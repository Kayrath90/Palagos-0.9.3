extends Node3D

# Palagos v0.9.3 – imported CC0 skinned 3D models and skeletal animations.
# Fallback procedural meshes remain for error recovery / nonplayer vendors.
const DATA = preload("res://scripts/game_data.gd")
const ITEMS = preload("res://scripts/item_data.gd")
const SAVE_PREFIX = "user://palagos_v06_"  # Preserve v0.6 Godot save files

func _save_path() -> String:
    return SAVE_PREFIX + current_class + ".json"
const ENEMY_MAX_HP = 152.0
const ENEMY_RESPAWN = 9.0
const COMBAT_SECONDS = 7.5

var current_class := "krieger"
var shared_world := false
var selected_enemy := -1
var level := 1
var xp := 0
var hp := 138.0
var mana := 260.0
var resource := 100.0
var quest_index := 0
var quest_progress := 0
var quest_accepted := false
var talents := [0, 0, 0]
var buffs := {"damage":0.0, "shield":0.0, "hot":0.0}
var cooldowns := [0.0, 0.0, 0.0]
var cast_slot := -1
var cast_remaining := 0.0
var cast_total := 0.0
var cast_target := -1
var in_combat_timer := 0.0
var game_running := false
var dialogue_open := false
var talent_open := false
var camera_yaw := 0.0
var camera_pitch := -0.18
var move_axis := Vector2.ZERO
var stick_id := -1
var look_id := -1
var look_last := Vector2.ZERO
var walk_phase := 0.0
var active_zone: Node3D
var hero: Node3D
var hero_limbs: Array[Node3D] = []
var hero_joints: Dictionary = {}
var cast_visual_clock := 0.0
var footstep_clock := 0.0
var enemies: Array[Dictionary] = []
var camera: Camera3D
var npc: Node3D
var overlay: Control
var hud: Control
var class_grid: GridContainer
var hp_bar: ProgressBar
var mana_bar: ProgressBar
var level_label: Label
var region_label: Label
var quest_label: Label
var target_label: Label
var cast_bar: ProgressBar
var cast_label: Label
var spell_buttons: Array[Button] = []
var talent_button: Button
var world_button: Button
var dialog_panel: PanelContainer
var dialog_title: Label
var dialog_text: Label
var dialog_accept: Button
var dialog_decline: Button
var talent_panel: PanelContainer
var talent_text: Label
var talent_buttons: Array[Button] = []
var msg_label: Label
var message_timer := 0.0
var joystick_circle: Panel
var joystick_knob: Panel
var floater_layer: Control
var floating_numbers: Array[Dictionary] = []
var nameplates: Array[Dictionary] = []
var rng := RandomNumberGenerator.new()
# v0.8 systems: retained separately from the older combat prototype.
var gold := 140
var bag: Array[Dictionary] = []
var gear: Dictionary = {}
var appearance := {"gender":0, "face":0, "hair":0}
var chosen_class := "krieger"
var music_player: AudioStreamPlayer
var music_level := 0.55
var music_muted := false
var title_screen: Control
var creator_screen: Control
var creator_preview: SubViewport
var preview_root: Node3D
var creator_name: Label
var gender_select: OptionButton
var face_select: OptionButton
var hair_select: OptionButton
var inventory_panel: PanelContainer
var inventory_grid: GridContainer
var inventory_info: Label
var inventory_action: Button
var selected_bag_slot := -1
var gear_panel: PanelContainer
var gear_list: VBoxContainer
var gear_stats: Label
var shop_panel: PanelContainer
var shop_grid: VBoxContainer
var shop_text: Label
var options_panel: PanelContainer
var volume_slider: HSlider
var volume_label: Label
var mute_check: CheckButton
var vendor_npcs: Array[Dictionary] = []
var active_merchant := ""
var active_subpanel := ""
var backpack_button: Button
var gear_button: Button
var camera_invert_x := false
var camera_invert_y := false
var preview_container: SubViewportContainer
var terrain_noise := FastNoiseLite.new()
var graphics_high := true
var landscape_clock := 0.0
# Combat animation state. Visuals are created per character; no external assets needed.
var weapon_rig: Node3D
var weapon_string_upper: MeshInstance3D
var weapon_string_lower: MeshInstance3D
var weapon_nocked_arrow: Node3D
var weapon_gem: MeshInstance3D
var attack_motion_time := 0.0
var attack_motion_duration := 0.0
var attack_motion_kind := ""
var animation_clock := 0.0
var missiles: Array[Dictionary] = []

# v0.9.3: imported, textured skeletal characters. Quaternius CC0 (see models/quaternius/LICENSE_CC0.txt).
const CHARACTER_FILES := {
    "krieger": "Warrior_Brown", "jaeger": "Ranger", "magier": "Wizard",
    "priester": "Cleric", "druide": "Monk", "paladin": "Warrior_Gold"
}
var imported_hero_animation: AnimationPlayer = null
var imported_preview_animation: AnimationPlayer = null
var imported_hero_model: Node3D = null
var imported_hero_moving := false
var imported_model_ready := false

func _ready() -> void:
    rng.seed = 241026
    terrain_noise.seed = 16421
    terrain_noise.frequency = 0.023
    terrain_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    terrain_noise.fractal_octaves = 4
    _load_camera_settings()
    _setup_world()
    _setup_music()
    _setup_ui()
    _show_title()

func cfg() -> Dictionary:
    return DATA.CLASSES[current_class]

func _setup_world() -> void:
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 68.0
    camera.far = 230.0
    add_child(camera)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-53, -36, 0)
    sun.light_energy = 1.45
    sun.shadow_enabled = true # phone-friendly shadows; compatibility renderer
    sun.directional_shadow_max_distance = 45.0
    add_child(sun)
    var environment := WorldEnvironment.new()
    var env := Environment.new()
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("253d61")
    sky_mat.sky_horizon_color = Color("c4b396")
    sky_mat.ground_bottom_color = Color("414947")
    sky.sky_material = sky_mat
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.75
    env.reflected_light_source = Environment.REFLECTION_SOURCE_BG
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color("86938a")
    env.fog_density = 0.0055
    environment.environment = env
    add_child(environment)

func _make_material(color: Color, emission_strength: float = 0.0) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.81
    if emission_strength > 0.0:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = emission_strength
    return mat

func _primitive(parent: Node3D, type_name: String, pos: Vector3, scale_value: Vector3, color: Color, emissive: float = 0.0) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh: PrimitiveMesh
    if type_name == "sphere":
        var sm := SphereMesh.new()
        sm.radial_segments = 20
        sm.rings = 12
        mesh = sm
    elif type_name == "capsule":
        var cm := CapsuleMesh.new()
        cm.radial_segments = 16
        cm.rings = 9
        mesh = cm
    elif type_name == "cylinder":
        var cy := CylinderMesh.new()
        cy.radial_segments = 9
        mesh = cy
    else:
        mesh = BoxMesh.new()
    node.mesh = mesh
    node.position = pos
    node.scale = scale_value
    node.material_override = _make_material(color, emissive)
    parent.add_child(node)
    return node

func _terrain_height(x: float, z: float) -> float:
    var radius := Vector2(x, z + 2.0).length()
    var flat_weight := smoothstep(13.0, 31.0, radius)
    var wave := sin(x * 0.063) * 1.15 + cos(z * 0.051 + x * 0.019) * 0.88
    var noise := terrain_noise.get_noise_2d(x, z) * 5.2
    return (wave + noise) * flat_weight

func _add_terrain_vertex(builder: SurfaceTool, world_pos: Vector3, tint: Color) -> void:
    builder.set_color(tint)
    builder.set_uv(Vector2(world_pos.x, world_pos.z) * 0.045)
    var sample := 0.20
    var dx := (_terrain_height(world_pos.x + sample, world_pos.z) - _terrain_height(world_pos.x - sample, world_pos.z)) / (2.0 * sample)
    var dz := (_terrain_height(world_pos.x, world_pos.z + sample) - _terrain_height(world_pos.x, world_pos.z - sample)) / (2.0 * sample)
    builder.set_normal(Vector3(-dx, 1.0, -dz).normalized())
    builder.add_vertex(world_pos)

func _make_ground() -> void:
    # One smooth, vertex-colored terrain mesh; no tiled cubes or per-cell draw calls.
    var surface := SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    var size := 184.0
    var count := 72
    var step := size / float(count)
    for zi in range(count):
        for xi in range(count):
            var x := -size * 0.5 + float(xi) * step
            var z := -size * 0.5 + float(zi) * step
            var a := Vector3(x, _terrain_height(x, z), z)
            var b := Vector3(x + step, _terrain_height(x + step, z), z)
            var c := Vector3(x, _terrain_height(x, z + step), z + step)
            var d := Vector3(x + step, _terrain_height(x + step, z + step), z + step)
            var tint := terrain_noise.get_noise_2d(x * 1.9 + 113.0, z * 1.9 + 109.0)
            var base := Color("536b4c") if shared_world else Color("597554").lerp(cfg()["theme"], 0.18)
            var color := base.lightened(clampf(tint * 0.28 + 0.10, -0.20, 0.28))
            for v in [a, c, b, b, c, d]:
                _add_terrain_vertex(surface, v, color)
    var ground := MeshInstance3D.new()
    ground.name = "Gelaende_Gewaechse_und_Huegel"
    ground.mesh = surface.commit()
    var ground_mat := _make_material(Color.WHITE)
    ground_mat.vertex_color_use_as_albedo = true
    ground_mat.roughness = 0.99
    ground_mat.albedo_texture = load("res://assets/terrain_grass.png")
    ground.material_override = ground_mat
    active_zone.add_child(ground)
    # Paths built as strips laid onto the rolling ground, not a flat box.
    var path := SurfaceTool.new()
    path.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in range(130):
        var z := -70.0 + float(i) * 1.0
        var zn := z + 1.0
        var x := sin(z * 0.052) * 1.8
        var xn := sin(zn * 0.052) * 1.8
        var width := 2.45 + sin(z * 0.11) * 0.20
        var a := Vector3(x - width, _terrain_height(x - width, z) + 0.07, z)
        var b := Vector3(x + width, _terrain_height(x + width, z) + 0.07, z)
        var c := Vector3(xn - width, _terrain_height(xn - width, zn) + 0.07, zn)
        var d := Vector3(xn + width, _terrain_height(xn + width, zn) + 0.07, zn)
        var tone := Color("99866a").lerp(Color("746b57"), absf(sin(z * 0.12)) * 0.18)
        for v in [a, b, c, b, d, c]:
            _add_terrain_vertex(path, v, tone)
    var road := MeshInstance3D.new()
    road.name = "Alter_Karawanenweg"
    road.mesh = path.commit()
    var road_mat := _make_material(Color.WHITE)
    road_mat.vertex_color_use_as_albedo = true
    road_mat.roughness = 1.0
    road_mat.albedo_texture = load("res://assets/terrain_path.png")
    road.material_override = road_mat
    active_zone.add_child(road)

func _instanced_mesh(label: String, primitive: Mesh, paint: Color, poses: Array, colors: Array = []) -> void:
    if poses.is_empty():
        return
    var material := _make_material(paint)
    # Never mutate a shared primitive: individual crown clusters need separate tints.
    var drawable := primitive.duplicate() as Mesh
    if label == "Wald_Baumstaemme":
        material.albedo_texture = load("res://assets/bark_worn.png")
    elif label.begins_with("Wald_Wipfel") or label == "Wald_Baumkronen":
        material.albedo_texture = load("res://assets/leaf_cluster.png")
    elif label == "Felsbrocken":
        material.albedo_texture = load("res://assets/rock_moss.png")
    elif label == "Grasbueschel":
        material.vertex_color_use_as_albedo = true
        material.cull_mode = BaseMaterial3D.CULL_DISABLED
    if drawable is PrimitiveMesh:
        (drawable as PrimitiveMesh).material = material
    else:
        drawable.surface_set_material(0, material)
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.use_colors = colors.size() == poses.size()
    multi.mesh = drawable
    multi.instance_count = poses.size()
    for i in range(poses.size()):
        multi.set_instance_transform(i, poses[i])
        if multi.use_colors:
            multi.set_instance_color(i, colors[i])
    var instanced := MultiMeshInstance3D.new()
    instanced.name = label
    instanced.multimesh = multi
    active_zone.add_child(instanced)

func _make_forest() -> void:
    var trunks: Array = []
    var crowns: Array = []
    var crowns_left: Array = []
    var crowns_right: Array = []
    var small_rocks: Array = []
    var grass: Array = []
    for i in range(185):
        var x := rng.randf_range(-87, 87)
        var z := rng.randf_range(-87, 87)
        if Vector2(x, z + 2).length() < 23.0 or absf(x - sin(z * 0.052) * 1.8) < 6.2:
            continue
        var height := rng.randf_range(3.2, 7.8)
        var scale_tree := rng.randf_range(0.78, 1.22)
        var yy := _terrain_height(x, z)
        var spin := Basis(Vector3.UP, rng.randf_range(0.0, TAU))
        trunks.append(Transform3D(spin.scaled(Vector3(0.33 * scale_tree, height, 0.33 * scale_tree)), Vector3(x, yy + height * 0.45, z)))
        crowns.append(Transform3D(spin.scaled(Vector3(1.8 * scale_tree, 1.6 * scale_tree, 1.55 * scale_tree)), Vector3(x, yy + height * 0.99, z)))
        crowns_left.append(Transform3D(spin.scaled(Vector3(1.24 * scale_tree, 1.2 * scale_tree, 1.24 * scale_tree)), Vector3(x - 0.95 * scale_tree, yy + height * 0.78, z + 0.42)))
        crowns_right.append(Transform3D(spin.scaled(Vector3(1.18 * scale_tree, 1.08 * scale_tree, 1.25 * scale_tree)), Vector3(x + 0.92 * scale_tree, yy + height * 0.85, z - 0.36)))
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.43
    trunk_mesh.bottom_radius = 0.91
    trunk_mesh.height = 1.0
    trunk_mesh.radial_segments = 9
    _instanced_mesh("Wald_Baumstaemme", trunk_mesh, Color("534333"), trunks)
    var canopy_mesh := SphereMesh.new()
    canopy_mesh.radial_segments = 12
    canopy_mesh.rings = 8
    _instanced_mesh("Wald_Baumkronen", canopy_mesh, Color("365e3d") if not shared_world else Color("3d6660"), crowns)
    _instanced_mesh("Wald_Wipfel_L", canopy_mesh, Color("466d48"), crowns_left)
    _instanced_mesh("Wald_Wipfel_R", canopy_mesh, Color("31583a"), crowns_right)
    var boulder_mesh := SphereMesh.new()
    boulder_mesh.radial_segments = 9
    boulder_mesh.rings = 6
    for i in range(76):
        var x := rng.randf_range(-88.0, 88.0)
        var z := rng.randf_range(-88.0, 88.0)
        if Vector2(x, z).length() < 15.0:
            continue
        var w := rng.randf_range(0.5, 2.35)
        var y := _terrain_height(x, z)
        var rotation := Basis(Vector3.UP, rng.randf_range(0.0, TAU))
        small_rocks.append(Transform3D(rotation.scaled(Vector3(w, w * rng.randf_range(0.35, 0.65), w * rng.randf_range(0.65, 1.18))), Vector3(x, y + 0.14, z)))
    _instanced_mesh("Felsbrocken", boulder_mesh, Color("666965"), small_rocks)
    var blade := SurfaceTool.new()
    blade.begin(Mesh.PRIMITIVE_TRIANGLES)
    for angle in [0.0, 1.05, 2.10]:
        var turn := Basis(Vector3.UP, angle)
        for v in [Vector3(-0.15, 0, 0), Vector3(0.13, 0, 0), Vector3(0.02, 0.76, 0.02)]:
            blade.set_color(Color("7d9460") if v.y > 0 else Color("4c743d"))
            blade.add_vertex(turn * v)
    blade.generate_normals()
    var blade_mesh := blade.commit()
    for i in range(2200):
        var x := rng.randf_range(-90.0, 90.0)
        var z := rng.randf_range(-90.0, 90.0)
        if Vector2(x, z + 2.0).length() < 17.0 or absf(x - sin(z * 0.052) * 1.8) < 3.5:
            continue
        var height := rng.randf_range(0.33, 0.90)
        var base := Basis(Vector3.UP, rng.randf_range(0.0, TAU)).scaled(Vector3(height, height, height))
        grass.append(Transform3D(base, Vector3(x, _terrain_height(x, z) + 0.035, z)))
    _instanced_mesh("Grasbueschel", blade_mesh, Color.WHITE, grass)
    _add_forest_collision(trunks, small_rocks)

func _add_forest_collision(trunks: Array, rocks: Array) -> void:
    # One physics body with many primitive shapes keeps hundreds of draw instances cheap.
    var solid := StaticBody3D.new()
    solid.name = "Wald_und_Felsen_Kollision"
    solid.collision_layer = 4
    solid.collision_mask = 0
    active_zone.add_child(solid)
    for transform in trunks:
        var trunk: Transform3D = transform
        var height := trunk.basis.get_scale().y
        var cylinder := CylinderShape3D.new()
        cylinder.radius = 0.42
        cylinder.height = maxf(1.7, height * 0.88)
        var shape := CollisionShape3D.new()
        shape.shape = cylinder
        shape.position = trunk.origin
        solid.add_child(shape)
    for transform in rocks:
        var rock: Transform3D = transform
        var radius := clampf(rock.basis.get_scale().x * 0.70, 0.38, 1.35)
        var ball := SphereShape3D.new()
        ball.radius = radius
        var shape := CollisionShape3D.new()
        shape.shape = ball
        shape.position = rock.origin
        solid.add_child(shape)

func _hut_roof(parent: Node3D, depth: float, half_width: float, roof_height: float, paint: Color) -> void:
    var roof := SurfaceTool.new()
    roof.begin(Mesh.PRIMITIVE_TRIANGLES)
    var h := 2.7
    var top := h + roof_height
    var vertices := [
        Vector3(-half_width, h, -depth), Vector3(-half_width, h, depth), Vector3(0, top, depth),
        Vector3(-half_width, h, -depth), Vector3(0, top, depth), Vector3(0, top, -depth),
        Vector3(0, top, -depth), Vector3(0, top, depth), Vector3(half_width, h, depth),
        Vector3(0, top, -depth), Vector3(half_width, h, depth), Vector3(half_width, h, -depth)
    ]
    for v in vertices:
        roof.set_uv(Vector2(v.x, v.z) * 0.15)
        roof.add_vertex(v)
    roof.generate_normals()
    var item := MeshInstance3D.new()
    item.mesh = roof.commit()
    var mat := _make_material(paint)
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.albedo_texture = load("res://assets/roof_shingles.png")
    item.material_override = mat
    parent.add_child(item)
    for side in [-1.0, 1.0]:
        _primitive(parent, "box", Vector3(side * half_width * 0.95, 2.60, 0), Vector3(0.17, 0.15, depth * 2.15), paint.darkened(0.34))

func _make_house(x: float, z: float, tint: Color, spin: float = 0.0) -> void:
    var hut := Node3D.new()
    hut.name = "Dorfhaus"
    hut.position = Vector3(x, _terrain_height(x, z), z)
    hut.rotation.y = spin
    active_zone.add_child(hut)
    # A visible mesh is not a collision object: walls need real physics shapes.
    var solid := StaticBody3D.new()
    solid.name = "Haus_Kollision"
    solid.collision_layer = 4
    solid.collision_mask = 0
    hut.add_child(solid)
    var outline := CollisionShape3D.new()
    var block := BoxShape3D.new()
    block.size = Vector3(4.65, 2.80, 4.55)
    outline.shape = block
    outline.position = Vector3(0, 1.40, 0)
    solid.add_child(outline)
    var walls := _primitive(hut, "box", Vector3(0, 1.35, 0), Vector3(4.6, 2.7, 4.5), tint)
    var plaster := _make_material(tint)
    plaster.albedo_texture = load("res://assets/village_plaster.png")
    walls.material_override = plaster
    _primitive(hut, "box", Vector3(0, 1.52, -2.30), Vector3(1.08, 1.80, 0.13), Color("483425"))
    _primitive(hut, "sphere", Vector3(0.39, 1.32, -2.42), Vector3(0.055, 0.055, 0.06), Color("c9a35e"), 0.9)
    for side in [-1.0, 1.0]:
        _primitive(hut, "box", Vector3(side * 2.20, 1.43, -2.25), Vector3(0.26, 2.85, 0.25), Color("46372c"))
        _primitive(hut, "box", Vector3(side * 1.51, 1.69, -2.37), Vector3(0.73, 0.65, 0.15), Color("dcb773"), 0.25)
        _primitive(hut, "box", Vector3(side * 1.51, 1.69, -2.47), Vector3(0.08, 0.72, 0.10), Color("523e2b"))
    _hut_roof(hut, 2.60, 2.85, 1.67, Color("503d37") if not shared_world else Color("4d444e"))
    _primitive(hut, "cylinder", Vector3(1.60, 3.94, 0.94), Vector3(0.40, 1.50, 0.42), Color("66645b"))

func _make_village() -> void:
    var base := Color("847e69").lerp(cfg()["theme"], 0.20)
    for plot in [[-18.0, -6.0, -0.4], [15.0, -5.0, 0.32], [-15.5, 8.0, 0.35], [15.5, 9.0, -0.34], [-8.0, 17.0, PI], [7.0, -23.0, 0.0]]:
        _make_house(plot[0], plot[1], base, plot[2])
    for i in range(14):
        var x := -18.0 + float(i) * 2.8
        var z := 21.0 if i < 7 else -25.0
        _primitive(active_zone, "cylinder", Vector3(x, _terrain_height(x, z) + 0.8, z), Vector3(0.14, 1.60, 0.14), Color("564634"))
    for pos in [Vector3(-5.2, 0, 0.5), Vector3(6.0, 0, -1.3), Vector3(-7.0, 0, 12.0)]:
        var y := _terrain_height(pos.x, pos.z)
        _primitive(active_zone, "cylinder", Vector3(pos.x, y + 1.28, pos.z), Vector3(0.12, 2.56, 0.12), Color("493627"))
        _primitive(active_zone, "sphere", Vector3(pos.x, y + 2.65, pos.z), Vector3(0.22, 0.28, 0.22), Color("f6c56c"), 1.45)
        var lamp := OmniLight3D.new()
        lamp.position = Vector3(pos.x, y + 2.65, pos.z)
        lamp.light_color = Color("ffc67d")
        lamp.light_energy = 0.55
        lamp.omni_range = 7.0
        lamp.shadow_enabled = false
        active_zone.add_child(lamp)

func _make_class_landmark() -> void:
    var shrine := Node3D.new()
    shrine.name = "Wahrzeichen_der_Startregion"
    shrine.position = Vector3(0.0, _terrain_height(0.0, 13.0), 13.0)
    active_zone.add_child(shrine)
    var primary: Color = cfg()["color"] if not shared_world else Color("bc80c4")
    _primitive(shrine, "cylinder", Vector3(0, 0.15, 0), Vector3(3.1, 0.30, 3.1), Color("67645e"))
    match current_class:
        "krieger":
            for side in [-1.0, 1.0]:
                _primitive(shrine, "cylinder", Vector3(side * 1.75, 2.20, 0), Vector3(0.46, 4.4, 0.46), Color("555966"))
            _primitive(shrine, "box", Vector3(0, 4.45, 0), Vector3(4.0, 0.55, 0.8), Color("5c616a"))
        "jaeger":
            _primitive(shrine, "cylinder", Vector3(0, 3.0, 0), Vector3(1.3, 6.0, 1.3), Color("645340"))
            _primitive(shrine, "cylinder", Vector3(0, 6.25, 0), Vector3(2.85, 0.54, 2.85), Color("534b3e"))
        "magier":
            _primitive(shrine, "cylinder", Vector3(0, 1.40, 0), Vector3(0.66, 2.8, 0.66), Color("515d81"))
            _primitive(shrine, "sphere", Vector3(0, 3.2, 0), Vector3(0.87, 0.87, 0.87), primary, 2.1)
        "priester":
            _primitive(shrine, "cylinder", Vector3(0, 2.5, 0), Vector3(0.53, 5.0, 0.53), Color("c8bda1"))
            _primitive(shrine, "box", Vector3(0, 3.65, -0.5), Vector3(2.15, 0.45, 0.57), primary, 0.8)
        "druide":
            _primitive(shrine, "cylinder", Vector3(0, 3.1, 0), Vector3(1.20, 6.2, 1.20), Color("544b37"))
            for side in [-1.0, 0.0, 1.0]:
                _primitive(shrine, "sphere", Vector3(side * 2.1, 6.4, 0), Vector3(2.70, 2.05, 2.45), Color("31583e"))
        "paladin":
            _primitive(shrine, "cylinder", Vector3(0, 3.1, 0), Vector3(0.65, 6.2, 0.65), Color("b9a98a"))
            _primitive(shrine, "sphere", Vector3(0, 6.5, 0), Vector3(0.62, 0.86, 0.58), primary, 1.4)

func _generate_zone() -> void:
    # Old missiles must never follow enemies from a destroyed/changed region.
    for missile_entry in missiles:
        if is_instance_valid(missile_entry["node"]):
            missile_entry["node"].queue_free()
    missiles.clear()
    if is_instance_valid(active_zone):
        active_zone.queue_free()
    enemies.clear()
    for plate in nameplates:
        if is_instance_valid(plate["panel"]):
            plate["panel"].queue_free()
    nameplates.clear()
    selected_enemy = -1
    active_zone = Node3D.new()
    active_zone.name = "Gemeinsame_Welt" if shared_world else cfg()["region"]
    add_child(active_zone)
    _make_ground()
    _make_forest()
    _make_village()
    _make_class_landmark()
    var shard_color: Color = cfg()["color"] if not shared_world else Color("a65cb9")
    for i in range(12):
        var x := 25.0 + float(i % 4) * 5.0
        var z := -24.0 - float(i / 4) * 9.0
        var crystal := Node3D.new()
        crystal.position = Vector3(x, _terrain_height(x, z), z)
        crystal.rotation.y = rng.randf_range(0.0, TAU)
        active_zone.add_child(crystal)
        var core := _primitive(crystal, "cylinder", Vector3(0, 1.20, 0), Vector3(0.34, 2.40, 0.36), shard_color, 1.25)
        core.rotation.z = rng.randf_range(-0.35, 0.35)
        _primitive(crystal, "sphere", Vector3(0, 0.18, 0), Vector3(0.92, 0.31, 0.92), Color("323337"))
    npc = _build_character(active_zone, Color("b3a58a"), "npc")
    npc.position = Vector3(0, _terrain_height(0, -5.1), -5.1)
    _build_vendors()
    var npc_name := Label3D.new()
    npc_name.text = "Seryn · Kernwacht" if not shared_world else "Seryn · Sammelpunkt"
    npc_name.position.y = 2.70
    npc_name.font_size = 38
    npc_name.pixel_size = 0.006
    npc_name.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    npc_name.modulate = Color("f5dc93")
    npc.add_child(npc_name)
    var talk_area := Area3D.new()
    talk_area.collision_layer = 2
    talk_area.collision_mask = 0
    talk_area.set_meta("npc", true)
    var npc_shape := CollisionShape3D.new()
    var sc := SphereShape3D.new()
    sc.radius = 1.2
    npc_shape.shape = sc
    npc_shape.position.y = 1.0
    talk_area.add_child(npc_shape)
    npc.add_child(talk_area)
    for i in range(8):
        var x := -17.0 + float(i % 4) * 11.0
        var z := -32.0 - float(i / 4) * 14.0
        _spawn_enemy(Vector3(x, _terrain_height(x, z), z), i)
    if is_instance_valid(hero):
        hero.position = Vector3(0, _terrain_height(0, 3.0), 3.0)
    camera_yaw = 0.0
    camera_pitch = -0.18


func _find_avatar_animation(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node as AnimationPlayer
    for child in node.get_children():
        var result: AnimationPlayer = _find_avatar_animation(child)
        if result != null:
            return result
    return null

func _play_avatar_clip(player: AnimationPlayer, candidates: Array[String]) -> void:
    if player == null or not is_instance_valid(player):
        return
    var available: PackedStringArray = player.get_animation_list()
    for desired in candidates:
        for anim_name in available:
            var label_name := str(anim_name)
            if label_name == desired or label_name.ends_with("/" + desired) or label_name.ends_with("|" + desired):
                if player.current_animation != label_name or not player.is_playing():
                    player.play(label_name, 0.14)
                return

func _import_quaternius_avatar(root: Node3D, tag: String) -> bool:
    if tag != "hero" and tag != "preview":
        return false
    var chosen := current_class if tag == "hero" else chosen_class
    var character_name: String = CHARACTER_FILES.get(chosen, "Warrior")
    var scene_path: String = "res://models/quaternius/" + character_name + ".gltf"
    var model_scene: PackedScene = load(scene_path) as PackedScene
    if model_scene == null:
        push_warning("3D-Modell nicht geladen: " + scene_path + "; verwende einfache Ersatzfigur")
        return false
    var model: Node3D = model_scene.instantiate() as Node3D
    if model == null:
        return false
    model.name = "Quaternius_" + character_name
    root.add_child(model)
    # Source characters measure about 3 m; scale them to ~2.15 m like the gameplay capsule.
    model.scale = Vector3.ONE * 0.73
    model.position = Vector3.ZERO
    var player: AnimationPlayer = _find_avatar_animation(model)
    if tag == "hero":
        imported_hero_model = model
        imported_hero_animation = player
        imported_model_ready = true
        hero_joints.clear()
        hero_limbs.clear()
        weapon_rig = null
        weapon_string_upper = null
        weapon_string_lower = null
        weapon_nocked_arrow = null
        weapon_gem = null
    else:
        imported_preview_animation = player
    # Each imported character already contains a weapon mesh bound to its skeleton.
    # Warrior_Brown and Warrior_Gold share the licensed rig but use independent texture palettes.
    _play_avatar_clip(player, ["Idle_Weapon", "Idle"])
    return true

func _update_imported_avatar_animation() -> void:
    if imported_hero_animation == null or not is_instance_valid(imported_hero_animation):
        return
    if cast_slot >= 0:
        if current_class == "jaeger":
            _play_avatar_clip(imported_hero_animation, ["Bow_Draw", "Idle_Attacking"])
        else:
            _play_avatar_clip(imported_hero_animation, ["Spell1", "Idle_Attacking", "Idle_Weapon"])
    elif attack_motion_time > 0.0:
        match current_class:
            "jaeger":
                _play_avatar_clip(imported_hero_animation, ["Bow_Shoot", "Idle_Attacking"])
            "krieger", "paladin":
                _play_avatar_clip(imported_hero_animation, ["Sword_Attack", "Sword_Attack2", "Attack"])
            _:
                _play_avatar_clip(imported_hero_animation, ["Spell2", "Spell1", "Staff_Attack"])
    elif imported_hero_moving:
        _play_avatar_clip(imported_hero_animation, ["Run_Weapon", "Run_Holding", "Run", "Walk"])
    else:
        _play_avatar_clip(imported_hero_animation, ["Idle_Weapon", "Idle", "Idle_Attacking"])

func _build_character(parent: Node3D, color: Color, tag: String) -> Node3D:
    # The character has animated shoulder, elbow, hip and knee pivots.
    # These are still procedural placeholder meshes; a skinned GLB will eventually replace them.
    # Hero uses Godot physics; preview and NPC models stay non-physical.
    var root: Node3D = CharacterBody3D.new() if tag == "hero" else Node3D.new()
    root.name = tag
    parent.add_child(root)
    if tag == "hero":
        var body := root as CharacterBody3D
        body.collision_layer = 1
        body.collision_mask = 4
        var capsule_shape := CollisionShape3D.new()
        var capsule := CapsuleShape3D.new()
        capsule.radius = 0.35
        capsule.height = 1.76
        capsule_shape.shape = capsule
        capsule_shape.position = Vector3(0, 1.0, 0)
        body.add_child(capsule_shape)
    if _import_quaternius_avatar(root, tag):
        return root
    var cloth := color.darkened(0.10)
    var trim := color.lightened(0.34)
    var skin_colors := [Color("c39475"), Color("d8ac89"), Color("ac7b5d"), Color("946b59")]
    var hair_colors := [Color("29201d"), Color("a66a36"), Color("e6ca83"), Color("b3b6ba")]
    var skin: Color = skin_colors[int(appearance["face"])] if tag in ["hero", "preview"] else Color("c39475")
    var hair: Color = hair_colors[int(appearance["hair"])] if tag in ["hero", "preview"] else Color("32281f")
    _primitive(root, "sphere", Vector3(0, 1.11, 0), Vector3(0.47, 0.33, 0.34), cloth)
    _primitive(root, "capsule", Vector3(0, 1.49, 0), Vector3(0.70, 1.04, 0.51), cloth)
    _primitive(root, "sphere", Vector3(0, 1.88, 0), Vector3(0.50, 0.23, 0.38), trim)
    _primitive(root, "sphere", Vector3(0, 1.53, -0.32), Vector3(0.47, 0.43, 0.12), color)
    _primitive(root, "cylinder", Vector3(0, 1.92, 0), Vector3(0.17, 0.22, 0.17), skin)
    _primitive(root, "sphere", Vector3(0, 2.19, -0.03), Vector3(0.33, 0.43, 0.32), skin)
    _primitive(root, "sphere", Vector3(0, 2.47, 0.005), Vector3(0.34, 0.19, 0.33), hair)
    if tag in ["hero", "preview"]:
        # Four distinguishable face silhouettes; gender affects proportions, not combat values.
        var face_index := int(appearance["face"])
        var jaw_width: float = float([0.34, 0.31, 0.40, 0.37][face_index])
        _primitive(root, "sphere", Vector3(0, 2.10, -0.035), Vector3(jaw_width, 0.31, 0.345), skin)
        var nose_size: float = float([0.095, 0.075, 0.11, 0.084][face_index])
        _primitive(root, "sphere", Vector3(0, 2.14, -0.385), Vector3(nose_size, 0.12, 0.10), skin.lightened(0.04))
        if int(appearance["gender"]) == 1:
            root.scale = Vector3(0.92, 0.95, 0.92)
    # Eyes face -Z, as does the player character when yaw is zero.
    for side in [-1.0, 1.0]:
        _primitive(root, "sphere", Vector3(side * 0.145, 2.23, -0.361), Vector3(0.058, 0.036, 0.027), Color("dfd4c6"))
        _primitive(root, "sphere", Vector3(side * 0.145, 2.23, -0.384), Vector3(0.020, 0.027, 0.011), Color("233a35"))
        _primitive(root, "sphere", Vector3(side * 0.14, 2.01, -0.30), Vector3(0.25, 0.11, 0.1), skin.darkened(0.11))
    # Sculpted class details: fabric seams, brow, footwear, buckles and layered armor.
    _primitive(root, "box", Vector3(0, 1.18, -0.28), Vector3(0.73, 0.15, 0.11), Color("43342c"))
    _primitive(root, "sphere", Vector3(0, 1.18, -0.36), Vector3(0.15, 0.105, 0.07), trim)
    for side in [-1.0, 1.0]:
        _primitive(root, "sphere", Vector3(side * 0.148, 2.325, -0.33), Vector3(0.105, 0.031, 0.036), hair.darkened(0.25))
        _primitive(root, "sphere", Vector3(side * 0.30, 2.16, 0.02), Vector3(0.075, 0.13, 0.105), skin)
    _primitive(root, "sphere", Vector3(0, 1.995, -0.348), Vector3(0.13, 0.028, 0.02), skin.darkened(0.32))
    if tag in ["preview", "hero"]:
        var class_key: String = chosen_class if tag == "preview" else current_class
        match class_key:
            "magier":
                _primitive(root, "cylinder", Vector3(0, 2.67, 0.01), Vector3(0.31, 0.50, 0.29), cloth.darkened(0.25))
                _primitive(root, "sphere", Vector3(0, 2.84, -0.03), Vector3(0.13, 0.14, 0.16), trim, 0.60)
            "priester":
                _primitive(root, "sphere", Vector3(0, 1.50, -0.43), Vector3(0.21, 0.21, 0.10), Color("f3dfac"), 0.45)
            "druide":
                for side in [-1.0, 1.0]:
                    var antler := _primitive(root, "cylinder", Vector3(side * 0.22, 2.75, 0), Vector3(0.06, 0.55, 0.06), Color("b1a178"))
                    antler.rotation.z = side * 0.34
            "paladin":
                _primitive(root, "sphere", Vector3(0, 1.52, -0.44), Vector3(0.22, 0.30, 0.075), Color("e0be77"))
            "krieger":
                _primitive(root, "sphere", Vector3(0, 1.60, -0.42), Vector3(0.30, 0.25, 0.082), Color("91a7ad"))
            "jaeger":
                _primitive(root, "sphere", Vector3(0, 1.87, 0.24), Vector3(0.46, 0.46, 0.12), Color("514832"))
    # Separate upper/lower arm and thigh/shin rotations for less puppet-like movement.
    var arms: Array[Node3D] = []
    var elbows: Array[Node3D] = []
    var legs: Array[Node3D] = []
    var knees: Array[Node3D] = []
    for side in [-1.0, 1.0]:
        var shoulder := Node3D.new()
        shoulder.position = Vector3(0.43 * side, 1.81, 0)
        root.add_child(shoulder)
        _primitive(shoulder, "sphere", Vector3(0, -0.035, 0), Vector3(0.26, 0.23, 0.28), trim)
        _primitive(shoulder, "capsule", Vector3(0, -0.32, 0), Vector3(0.225, 0.59, 0.22), cloth)
        var elbow := Node3D.new()
        elbow.position = Vector3(0, -0.59, 0)
        shoulder.add_child(elbow)
        _primitive(elbow, "capsule", Vector3(0, -0.28, 0), Vector3(0.19, 0.55, 0.19), cloth.darkened(0.18))
        _primitive(elbow, "sphere", Vector3(0, -0.59, -0.015), Vector3(0.21, 0.23, 0.20), skin)
        arms.append(shoulder)
        elbows.append(elbow)
        var hip := Node3D.new()
        hip.position = Vector3(0.19 * side, 1.10, 0)
        root.add_child(hip)
        _primitive(hip, "capsule", Vector3(0, -0.32, 0), Vector3(0.255, 0.61, 0.25), cloth.darkened(0.34))
        var knee := Node3D.new()
        knee.position = Vector3(0, -0.59, 0)
        hip.add_child(knee)
        _primitive(knee, "capsule", Vector3(0, -0.285, 0), Vector3(0.22, 0.55, 0.22), Color("343839"))
        _primitive(knee, "sphere", Vector3(0, -0.55, -0.105), Vector3(0.27, 0.20, 0.40), Color("24292e"))
        legs.append(hip)
        knees.append(knee)
    if tag == "hero":
        hero_limbs = arms + legs
        hero_joints = {"arms":arms, "elbows":elbows, "legs":legs, "knees":knees}
        # A little readable class identity, even with no externally imported assets.
        match current_class:
            "magier", "priester", "druide":
                _primitive(root, "cylinder", Vector3(0, 0.77, 0), Vector3(0.56, 0.90, 0.53), cloth.darkened(0.18))
                _primitive(root, "sphere", Vector3(0, 2.53, 0.05), Vector3(0.47, 0.17, 0.42), color)
            "krieger", "paladin":
                _primitive(root, "sphere", Vector3(0, 1.70, -0.40), Vector3(0.40, 0.30, 0.085), trim)
                _primitive(root, "sphere", Vector3(0, 0.96, -0.30), Vector3(0.40, 0.09, 0.10), trim)
            "jaeger":
                _primitive(root, "sphere", Vector3(0, 1.78, 0.30), Vector3(0.56, 0.55, 0.15), cloth.darkened(0.2))
    if tag in ["preview", "hero"]:
        _make_character_weapon(root, chosen_class if tag == "preview" else current_class, tag == "hero")
    return root


# --- PALAGOS 0.9.2: visible equipment and combat presentation ---
func _rod(parent: Node3D, a: Vector3, b: Vector3, width: float, paint: Color, glow: float = 0.0) -> MeshInstance3D:
    # Unit-length CylinderMesh stretches between two points. It can be repositioned for a drawn bowstring.
    var piece := _primitive(parent, "cylinder", Vector3.ZERO, Vector3.ONE, paint, glow)
    _position_rod(piece, a, b, width)
    return piece

func _position_rod(piece: MeshInstance3D, a: Vector3, b: Vector3, width: float) -> void:
    var along := b - a
    var length := along.length()
    if length < 0.0001:
        return
    piece.position = (a + b) * 0.5
    piece.basis = Basis(Quaternion(Vector3.UP, along / length))
    piece.scale = Vector3(width, length * 0.5, width)

func _make_character_weapon(root: Node3D, class_id: String, playable: bool) -> void:
    var rig := Node3D.new()
    rig.name = "HeldWeaponVisual"
    root.add_child(rig)
    if playable:
        weapon_rig = rig
        weapon_string_upper = null
        weapon_string_lower = null
        weapon_nocked_arrow = null
        weapon_gem = null
    var equipped := str(gear.get("weapon", "")) if playable else ITEMS.starter_weapon(class_id)
    if equipped == "":
        return
    if equipped == "hunter_bow":
        rig.position = Vector3(-0.63, 1.40, -0.51)
        rig.rotation.z = -0.12
        var bronze := Color("a77b43")
        var limbs := [Vector3(0.22, -0.85, 0.1), Vector3(0.035, -0.56, -0.015), Vector3(-0.10, -0.23, -0.10), Vector3(-0.13, 0, -0.12), Vector3(-0.10, 0.23, -0.10), Vector3(0.035, 0.56, -0.015), Vector3(0.22, 0.85, 0.1)]
        for j in range(limbs.size() - 1):
            _rod(rig, limbs[j], limbs[j + 1], 0.052, bronze if j not in [2, 3] else Color("59412e"))
        _primitive(rig, "capsule", Vector3(-0.13, 0, -0.12), Vector3(0.12, 0.30, 0.14), Color("43372d"))
        var top := limbs[limbs.size() - 1]
        var bottom := limbs[0]
        var pull := Vector3(0.0, 0, 0.18)
        var upper := _rod(rig, top, pull, 0.013, Color("efe1c2"))
        var lower := _rod(rig, bottom, pull, 0.013, Color("efe1c2"))
        if playable:
            weapon_string_upper = upper
            weapon_string_lower = lower
        var nock := Node3D.new()
        nock.name = "NockedArrow"
        rig.add_child(nock)
        _rod(nock, Vector3(0, 0, -0.76), Vector3(0, 0, 0.30), 0.022, Color("c3a070"))
        var head := _primitive(nock, "sphere", Vector3(0, 0, -0.79), Vector3(0.085, 0.065, 0.14), Color("c9d5d9"))
        head.rotation.x = 0.0
        for side in [-1.0, 1.0]:
            _primitive(nock, "sphere", Vector3(side * 0.065, 0, 0.21), Vector3(0.07, 0.025, 0.15), Color("d3e0d3"))
        nock.visible = false
        if playable:
            weapon_nocked_arrow = nock
    elif equipped == "star_staff":
        rig.position = Vector3(0.61, 1.32, -0.23)
        rig.rotation.z = -0.17
        _rod(rig, Vector3(0, -1.12, 0), Vector3(0, 1.20, 0), 0.065, Color("60422e"))
        _rod(rig, Vector3(-0.20, 1.00, 0), Vector3(0, 1.37, 0), 0.047, Color("b8a477"))
        _rod(rig, Vector3(0.20, 1.00, 0), Vector3(0, 1.37, 0), 0.047, Color("b8a477"))
        var magical: Color = Color("f4d6a8") if class_id == "priester" else Color("73dda5") if class_id == "druide" else Color("69b8ed")
        var gem := _primitive(rig, "sphere", Vector3(0, 1.43, 0), Vector3(0.15, 0.21, 0.15), magical, 2.5)
        _primitive(rig, "sphere", Vector3(0, 1.44, 0), Vector3(0.23, 0.29, 0.23), magical.darkened(0.4), 0.4)
        if playable:
            weapon_gem = gem
    elif equipped == "iron_sword":
        rig.position = Vector3(0.60, 1.11, -0.30)
        rig.rotation.z = PI - 0.20 # Blade is sheathed downward near the right hip.
        _rod(rig, Vector3(0, -0.37, 0), Vector3(0, 0.29, 0), 0.07, Color("422f24"))
        _rod(rig, Vector3(-0.27, 0.24, 0), Vector3(0.27, 0.24, 0), 0.07, Color("b69b62"))
        _rod(rig, Vector3(0, 0.27, 0), Vector3(0, 1.45, 0), 0.11, Color("b6c7cd"))
        _primitive(rig, "sphere", Vector3(0, 1.49, 0), Vector3(0.15, 0.22, 0.085), Color("e8e8e2"))
        _primitive(rig, "sphere", Vector3(0, -0.39, 0), Vector3(0.14, 0.14, 0.14), Color("b69b62"))
        if class_id == "paladin":
            _primitive(root, "sphere", Vector3(-0.65, 1.21, -0.25), Vector3(0.12, 0.62, 0.51), Color("b6a26c"))
            _primitive(root, "sphere", Vector3(-0.73, 1.25, -0.34), Vector3(0.055, 0.44, 0.35), Color("70868f"))

func _refresh_visible_weapon() -> void:
    # Item inventory is authoritative: model reflects equipped weapon, not class by default.
    if not is_instance_valid(hero):
        return
    if imported_model_ready:
        return # The imported character already has a skinned sword/staff/bow.
    if is_instance_valid(weapon_rig):
        weapon_rig.queue_free()
        weapon_rig = null
    _make_character_weapon(hero, current_class, true)

func _begin_attack_motion(slot: int, kind: String, length: float) -> void:
    attack_motion_kind = kind
    attack_motion_time = length
    attack_motion_duration = maxf(length, 0.01)

func _face_target(target: int) -> void:
    if _target_valid(target):
        var to_target: Vector3 = enemies[target]["node"].position - hero.position
        if to_target.length_squared() > 0.01:
            hero.rotation.y = atan2(-to_target.x, -to_target.z)

func _animate_weapon_frame(delta: float) -> void:
    animation_clock += delta
    if attack_motion_time > 0.0:
        attack_motion_time = maxf(0.0, attack_motion_time - delta)
    if not is_instance_valid(weapon_rig) or not is_instance_valid(hero):
        return
    var t: float = 1.0 - attack_motion_time / maxf(0.01, attack_motion_duration)
    var playing := attack_motion_time > 0.0
    var drawing := playing and attack_motion_kind == "bow_draw"
    var swinging := playing and attack_motion_kind == "sword"
    var releasing := playing and attack_motion_kind == "bow_release"
    var channeling := cast_slot >= 0 and current_class in ["magier", "priester", "druide"]
    var aura := channeling or (playing and attack_motion_kind == "cast_release")
    var ready := (0.0 if not playing else sin(t * PI))
    if current_class == "jaeger":
        weapon_rig.position = weapon_rig.position.lerp(Vector3(-0.65, 1.62, -0.65) if drawing or releasing else Vector3(-0.49, 1.41, 0.39), minf(1.0, delta * 13))
        weapon_rig.rotation.z = lerpf(weapon_rig.rotation.z, 0.0 if drawing or releasing else -0.58, minf(1, delta * 12))
        if is_instance_valid(weapon_nocked_arrow):
            weapon_nocked_arrow.visible = drawing
            if drawing:
                weapon_nocked_arrow.position.z = t * 0.45
        if is_instance_valid(weapon_string_upper) and is_instance_valid(weapon_string_lower):
            var draw_depth := t * 0.48 if drawing else 0.0
            var top := Vector3(0.22, 0.85, 0.10)
            var bottom := Vector3(0.22, -0.85, 0.10)
            var middle := Vector3(0, 0, 0.18 + draw_depth)
            _position_rod(weapon_string_upper, top, middle, 0.013)
            _position_rod(weapon_string_lower, bottom, middle, 0.013)
    elif current_class in ["krieger", "paladin"]:
        weapon_rig.position = weapon_rig.position.lerp(Vector3(0.75, 1.40, -0.63) if swinging else Vector3(0.60, 1.11, -0.30), minf(1, delta * 14))
        var slash_angle := -0.55 + t * 3.35
        weapon_rig.rotation.z = lerpf(weapon_rig.rotation.z, slash_angle if swinging else PI - 0.20, minf(1, delta * 20))
        weapon_rig.rotation.x = lerpf(weapon_rig.rotation.x, -0.50 * ready if swinging else 0.0, minf(1, delta * 12))
    else:
        weapon_rig.position = weapon_rig.position.lerp(Vector3(0.55, 1.41, -0.42) if aura else Vector3(0.61, 1.32, -0.23), minf(1, delta * 12))
        weapon_rig.rotation.z = lerpf(weapon_rig.rotation.z, -0.35 if aura else -0.17, minf(1, delta * 10))
        if is_instance_valid(weapon_gem):
            var pulse := 1.0 + (0.21 if aura else 0.045) * sin(animation_clock * (12.0 if aura else 3.0))
            weapon_gem.scale = Vector3(0.15, 0.21, 0.15) * pulse
    if not hero_joints.is_empty():
        var arms: Array = hero_joints["arms"]
        var elbows: Array = hero_joints["elbows"]
        if drawing or releasing:
            arms[0].rotation.x = lerpf(arms[0].rotation.x, 1.26, minf(1, delta * 16))
            arms[1].rotation.x = lerpf(arms[1].rotation.x, 1.22 if drawing else 0.54, minf(1, delta * 16))
            arms[1].rotation.z = lerpf(arms[1].rotation.z, -0.45, minf(1, delta * 16))
            elbows[1].rotation.x = lerpf(elbows[1].rotation.x, -0.95 if drawing else -0.24, minf(1, delta * 16))
        elif swinging:
            arms[1].rotation.x = lerpf(arms[1].rotation.x, 1.2 * ready, minf(1, delta * 16))
            arms[1].rotation.z = lerpf(arms[1].rotation.z, -0.90 + t * 1.6, minf(1, delta * 16))
        elif channeling:
            arms[0].rotation.x = lerpf(arms[0].rotation.x, 1.04, minf(1, delta * 10))
            arms[1].rotation.x = lerpf(arms[1].rotation.x, 0.72, minf(1, delta * 10))

func _launch_spell_missile(target: int, amount: float, slot: int) -> void:
    if not _target_valid(target):
        return
    var is_arrow := current_class == "jaeger"
    var is_fire := current_class == "magier" and slot == 1
    var is_nature := current_class == "druide"
    var tint: Color = Color("b2c6d0") if is_arrow else Color("ff7738") if is_fire else Color("6edc94") if is_nature else Color("f6dc99") if current_class == "priester" else Color("76a7ff")
    var missile := Node3D.new()
    missile.name = "ArrowInFlight" if is_arrow else "PalagosSpellProjectile"
    add_child(missile)
    var start := hero.global_position + Vector3(0, 1.55, 0) - hero.global_transform.basis.z * 0.7
    missile.global_position = start
    if is_arrow:
        _rod(missile, Vector3(0, 0, -0.52), Vector3(0, 0, 0.39), 0.028, Color("c8a178"))
        _primitive(missile, "sphere", Vector3(0, 0, -0.60), Vector3(0.075, 0.07, 0.14), Color("cbd3d8"))
        for side in [-1.0, 1.0]:
            _primitive(missile, "sphere", Vector3(side * 0.05, 0, 0.31), Vector3(0.065, 0.025, 0.14), Color("d7ddd3"))
    else:
        _primitive(missile, "sphere", Vector3.ZERO, Vector3.ONE * (0.25 if is_fire else 0.17), tint, 3.1)
        _primitive(missile, "sphere", Vector3.ZERO, Vector3.ONE * (0.38 if is_fire else 0.25), tint.darkened(0.45), 0.6)
        for p in range(4):
            var angle := float(p) * TAU / 4.0
            _primitive(missile, "sphere", Vector3(cos(angle) * 0.24, sin(angle) * 0.24, 0.06), Vector3.ONE * 0.065, tint.lightened(0.26), 2.0)
    missiles.append({"node":missile, "id":target, "damage":amount, "aoe":slot == 1 and current_class in ["jaeger", "magier"], "color":tint, "speed":24.0 if is_arrow else 13.0, "lifetime":2.5, "trail_timer":0.0, "is_arrow":is_arrow})

func _update_missiles(delta: float) -> void:
    for index in range(missiles.size() - 1, -1, -1):
        var item: Dictionary = missiles[index]
        var node: Node3D = item["node"]
        item["lifetime"] = float(item["lifetime"]) - delta
        if not is_instance_valid(node) or not _target_valid(int(item["id"])) or float(item["lifetime"]) <= 0:
            if is_instance_valid(node):
                node.queue_free()
            missiles.remove_at(index)
            continue
        var goal: Vector3 = enemies[int(item["id"])]["node"].global_position + Vector3(0, 1.0, 0)
        var direction: Vector3 = goal - node.global_position
        var step := float(item["speed"]) * delta
        if direction.length() <= step + 0.26:
            if bool(item["aoe"]):
                _damage_near(goal, 4.8, float(item["damage"]))
            else:
                _damage_enemy(int(item["id"]), float(item["damage"]))
            _spell_effect(goal, item["color"], 0.5 if not item["aoe"] else 1.1)
            node.queue_free()
            missiles.remove_at(index)
        else:
            node.look_at(goal, Vector3.UP)
            node.global_position += direction.normalized() * step
            if not bool(item["is_arrow"]):
                item["trail_timer"] = float(item["trail_timer"]) - delta
                if float(item["trail_timer"]) <= 0.0:
                    item["trail_timer"] = 0.15
                    _spell_effect(node.global_position, item["color"], 0.10)

func _spawn_enemy(pos: Vector3, ident: int) -> void:
    var monster := Node3D.new()
    monster.position = pos
    var variant := ident % 3
    var species := ["Kernbrut", "Bohrling", "Verderbter Waldjäger"]
    var body_color: Color = [Color("69566f"), Color("666b83"), Color("5d765c")][variant]
    var enemy_health: float = float([152, 187, 132][variant])
    monster.name = "%s_%02d" % [species[variant], ident]
    active_zone.add_child(monster)
    var body := _primitive(monster, "capsule", Vector3(0, 0.84, 0), Vector3(1.08, 0.75, 0.8), body_color)
    _primitive(monster, "sphere", Vector3(0, 1.28, -0.48), Vector3(0.54, 0.48, 0.60), body_color.darkened(0.25))
    for side in [-1.0, 1.0]:
        _primitive(monster, "capsule", Vector3(side * 0.63, 0.31, 0.31), Vector3(0.20, 0.62, 0.20), body_color.darkened(0.30))
        var horn := _primitive(monster, "cylinder", Vector3(side * 0.26, 1.69, -0.36), Vector3(0.13, 0.48, 0.13), Color("b0a398"))
        horn.rotation.z = side * 0.55
    if variant == 1:
        _primitive(monster, "cylinder", Vector3(0, 1.9, 0.04), Vector3(0.40, 1.55, 0.40), Color("a067c0"), 0.32)
        _primitive(monster, "sphere", Vector3(0, 1.95, -0.42), Vector3(0.30, 0.32, 0.38), Color("a78ec3"))
    elif variant == 2:
        for side in [-1.0, 1.0]:
            _primitive(monster, "capsule", Vector3(side * 0.52, 0.48, 0.10), Vector3(0.23, 0.72, 0.24), Color("354b31"))
            _primitive(monster, "sphere", Vector3(side * 0.44, 1.57, -0.55), Vector3(0.20, 0.50, 0.25), Color("b6a681"))
    _primitive(monster, "sphere", Vector3(-0.22, 1.36, -0.91), Vector3(0.10, 0.13, 0.10), Color("ed648b"), 2.3)
    _primitive(monster, "sphere", Vector3(0.22, 1.36, -0.91), Vector3(0.10, 0.13, 0.10), Color("ed648b"), 2.3)
    var collider := Area3D.new()
    collider.collision_layer = 2
    collider.collision_mask = 0
    collider.set_meta("enemy_id", ident)
    var shape := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 1.1
    shape.position.y = 0.95
    shape.shape = sphere
    collider.add_child(shape)
    monster.add_child(collider)
    enemies.append({"id":ident, "node":monster, "body":body, "home":pos, "name":species[variant], "hp":enemy_health, "max_hp":enemy_health, "speed":float([2.0, 1.5, 2.35][variant]), "attack":int([5, 8, 4][variant]), "alive":true, "respawn":0.0, "attack_cd":1.2, "stunned":0.0})
    var plate := PanelContainer.new()
    plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var vbox := VBoxContainer.new()
    vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
    plate.add_child(vbox)
    var name := Label.new()
    name.text = species[variant]
    name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    name.mouse_filter = Control.MOUSE_FILTER_IGNORE
    vbox.add_child(name)
    var health := ProgressBar.new()
    health.show_percentage = false
    health.mouse_filter = Control.MOUSE_FILTER_IGNORE
    health.custom_minimum_size = Vector2(100, 9)
    health.max_value = enemy_health
    health.value = enemy_health
    vbox.add_child(health)
    floater_layer.add_child(plate)
    nameplates.append({"panel":plate,"bar":health})

func _setup_ui() -> void:
    var canvas := CanvasLayer.new()
    canvas.layer = 10
    add_child(canvas)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    canvas.add_child(root)
    floater_layer = Control.new()
    floater_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    floater_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(floater_layer)
    hud = Control.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hud)
    var top := VBoxContainer.new()
    top.position = Vector2(14, 12)
    top.custom_minimum_size = Vector2(250, 0)
    hud.add_child(top)
    level_label = _label(top, "PALAGOS", 19)
    hp_bar = _bar(top, 150, Color("b64d4d"))
    mana_bar = _bar(top, 260, Color("4a8bd6"))
    region_label = _label(top, "", 15)
    quest_label = _label(top, "", 13)
    target_label = Label.new()
    target_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    target_label.anchor_left = 0.35
    target_label.anchor_right = 0.65
    target_label.offset_top = 12
    hud.add_child(target_label)
    var bottom := HBoxContainer.new()
    bottom.anchor_left = 0.54
    bottom.anchor_right = 1.0
    bottom.anchor_top = 1.0
    bottom.anchor_bottom = 1.0
    bottom.offset_left = -10
    bottom.offset_right = -12
    bottom.offset_top = -94
    bottom.offset_bottom = -18
    bottom.add_theme_constant_override("separation", 7)
    hud.add_child(bottom)
    for i in range(3):
        var btn := Button.new()
        btn.custom_minimum_size = Vector2(94, 58)
        btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        btn.pressed.connect(_activate_slot.bind(i))
        bottom.add_child(btn)
        spell_buttons.append(btn)
    var misc := HBoxContainer.new()
    misc.anchor_right = 1.0
    misc.offset_left = -685
    misc.offset_right = -12
    misc.offset_top = 14
    misc.add_theme_constant_override("separation", 6)
    hud.add_child(misc)
    talent_button = Button.new()
    talent_button.text = "Talente"
    talent_button.pressed.connect(_toggle_talents)
    misc.add_child(talent_button)
    backpack_button = Button.new()
    backpack_button.text = "Tasche"
    backpack_button.pressed.connect(_toggle_inventory)
    misc.add_child(backpack_button)
    gear_button = Button.new()
    gear_button.text = "Ausrüstung"
    gear_button.pressed.connect(_toggle_gear)
    misc.add_child(gear_button)
    var options_button := Button.new()
    options_button.text = "Optionen"
    options_button.pressed.connect(_toggle_options)
    misc.add_child(options_button)
    world_button = Button.new()
    world_button.text = "Welt ab Stufe 10"
    world_button.pressed.connect(_request_shared_world)
    misc.add_child(world_button)
    var menu_btn := Button.new()
    menu_btn.text = "Menü"
    menu_btn.pressed.connect(_toggle_menu)
    misc.add_child(menu_btn)
    cast_bar = ProgressBar.new()
    cast_bar.anchor_left = 0.35
    cast_bar.anchor_right = 0.65
    cast_bar.anchor_top = 0.80
    cast_bar.anchor_bottom = 0.80
    cast_bar.offset_top = -7
    cast_bar.offset_bottom = 11
    cast_bar.show_percentage = false
    cast_bar.max_value = 1.0
    cast_bar.visible = false
    hud.add_child(cast_bar)
    cast_label = Label.new()
    cast_label.anchor_left = 0.35
    cast_label.anchor_right = 0.65
    cast_label.anchor_top = 0.80
    cast_label.offset_top = -30
    cast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud.add_child(cast_label)
    msg_label = Label.new()
    msg_label.anchor_left = 0.2
    msg_label.anchor_right = 0.8
    msg_label.anchor_top = 0.22
    msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    msg_label.add_theme_font_size_override("font_size", 21)
    hud.add_child(msg_label)
    joystick_circle = Panel.new()
    joystick_circle.anchor_top = 1.0
    joystick_circle.anchor_bottom = 1.0
    joystick_circle.offset_left = 45
    joystick_circle.offset_right = 171
    joystick_circle.offset_top = -168
    joystick_circle.offset_bottom = -42
    joystick_circle.modulate = Color(1, 1, 1, 0.33)
    joystick_circle.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(joystick_circle)
    joystick_knob = Panel.new()
    joystick_knob.position = Vector2(46, 46)
    joystick_knob.size = Vector2(34, 34)
    joystick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joystick_circle.add_child(joystick_knob)
    _setup_dialogs(hud)
    _setup_system_panels(hud)
    _setup_selection(root)
    _setup_options(root)
    hud.visible = false

func _label(parent: Node, caption: String, size_value: int = 15) -> Label:
    var l := Label.new()
    l.text = caption
    l.add_theme_font_size_override("font_size", size_value)
    parent.add_child(l)
    return l

func _bar(parent: Node, max_val: float, tint: Color) -> ProgressBar:
    var b := ProgressBar.new()
    b.custom_minimum_size = Vector2(230, 16)
    b.max_value = max_val
    b.value = max_val
    b.show_percentage = false
    var fill := StyleBoxFlat.new()
    fill.bg_color = tint
    fill.corner_radius_top_left = 4
    fill.corner_radius_bottom_left = 4
    fill.corner_radius_top_right = 4
    fill.corner_radius_bottom_right = 4
    b.add_theme_stylebox_override("fill", fill)
    parent.add_child(b)
    return b

func _setup_selection(root: Control) -> void:
    overlay = Control.new()
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(overlay)
    var backdrop := TextureRect.new()
    backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    backdrop.texture = load("res://assets/title_palagos.png")
    backdrop.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    backdrop.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
    overlay.add_child(backdrop)
    var shade := ColorRect.new()
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.color = Color(0.025, 0.04, 0.07, 0.54)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    overlay.add_child(shade)
    title_screen = CenterContainer.new()
    title_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.add_child(title_screen)
    var title_box := VBoxContainer.new()
    title_box.custom_minimum_size = Vector2(510, 360)
    title_box.add_theme_constant_override("separation", 22)
    title_screen.add_child(title_box)
    var title := _label(title_box, "P A L A G O S", 53)
    title.add_theme_color_override("font_color", Color("f1d7ac"))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var subtitle := _label(title_box, "DAS HERZ DER FINSTERNIS", 21)
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var story := _label(title_box, "Fremde Mächte bohren bis zum Herz des Planeten.\nDie ersten Wächter erheben sich.", 17)
    story.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var start_btn := Button.new()
    start_btn.text = "SPIEL STARTEN"
    start_btn.custom_minimum_size.y = 62
    start_btn.pressed.connect(_show_creator)
    title_box.add_child(start_btn)
    var options_btn := Button.new()
    options_btn.text = "OPTIONEN · MUSIK"
    options_btn.custom_minimum_size.y = 48
    options_btn.pressed.connect(_toggle_options)
    title_box.add_child(options_btn)
    creator_screen = CenterContainer.new()
    creator_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.add_child(creator_screen)
    var scroller := ScrollContainer.new()
    scroller.custom_minimum_size = Vector2(920, 610)
    creator_screen.add_child(scroller)
    var content := VBoxContainer.new()
    content.custom_minimum_size = Vector2(890, 580)
    content.add_theme_constant_override("separation", 12)
    scroller.add_child(content)
    var heading := _label(content, "CHARAKTER ERSTELLEN", 27)
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    content.add_child(row)
    var left := VBoxContainer.new()
    left.custom_minimum_size.x = 500
    left.add_theme_constant_override("separation", 9)
    row.add_child(left)
    creator_name = _label(left, "Krieger · Eisenklamm", 19)
    class_grid = GridContainer.new()
    class_grid.columns = 2
    left.add_child(class_grid)
    for id in DATA.ORDER:
        var c: Dictionary = DATA.CLASSES[id]
        var btn := Button.new()
        btn.text = str(c["name"]) + " · " + str(c["region"])
        btn.custom_minimum_size = Vector2(242, 48)
        btn.pressed.connect(_choose_class.bind(id))
        class_grid.add_child(btn)
    var options := HBoxContainer.new()
    options.add_theme_constant_override("separation", 8)
    left.add_child(options)
    gender_select = OptionButton.new()
    gender_select.add_item("Männlich")
    gender_select.add_item("Weiblich")
    gender_select.custom_minimum_size.x = 135
    gender_select.item_selected.connect(_change_gender)
    options.add_child(gender_select)
    face_select = OptionButton.new()
    for i in range(4):
        face_select.add_item("Gesicht %d" % (i + 1))
    face_select.custom_minimum_size.x = 135
    face_select.item_selected.connect(_change_face)
    options.add_child(face_select)
    hair_select = OptionButton.new()
    for value in ["Schwarz", "Braun", "Blond", "Silber"]:
        hair_select.add_item(value)
    hair_select.custom_minimum_size.x = 135
    hair_select.item_selected.connect(_change_hair)
    options.add_child(hair_select)
    var hint := _label(left, "Jede Klasse hat später ein eigenes Startgebiet bis Stufe 10.\nMaximale Stufe dieser Testphase: 20.", 14)
    hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    var right := VBoxContainer.new()
    right.custom_minimum_size = Vector2(360, 400)
    row.add_child(right)
    var preview_label := _label(right, "3D-CHARAKTERVORSCHAU", 16)
    preview_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    preview_label.add_theme_color_override("font_color", Color("f1d5ab"))
    # SubViewportContainer displays live 3D reliably as a UI control on Android.
    preview_container = SubViewportContainer.new()
    preview_container.name = "Live3DPreviewContainer"
    preview_container.custom_minimum_size = Vector2(352, 395)
    preview_container.stretch = true
    right.add_child(preview_container)
    creator_preview = SubViewport.new()
    creator_preview.name = "Character3DViewport"
    creator_preview.size = Vector2i(352, 395)
    creator_preview.own_world_3d = true
    creator_preview.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    creator_preview.render_target_clear_mode = SubViewport.CLEAR_MODE_ALWAYS
    creator_preview.transparent_bg = false
    creator_preview.msaa_3d = Viewport.MSAA_2X
    preview_container.add_child(creator_preview)
    _setup_preview_scene()
    var controls := HBoxContainer.new()
    content.add_child(controls)
    var back := Button.new()
    back.text = "ZURÜCK"
    back.custom_minimum_size = Vector2(180, 54)
    back.pressed.connect(_show_title)
    controls.add_child(back)
    var play := Button.new()
    play.text = "ABENTEUER BEGINNEN"
    play.custom_minimum_size = Vector2(520, 54)
    play.pressed.connect(_start_chosen_game)
    controls.add_child(play)
    creator_screen.visible = false

func _setup_preview_scene() -> void:
    var stage := Node3D.new()
    creator_preview.add_child(stage)
    var cam := Camera3D.new()
    stage.add_child(cam)
    cam.position = Vector3(0, 2.12, -5.0)
    cam.look_at(Vector3(0, 1.46, 0), Vector3.UP)
    cam.make_current()
    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-35, -30, 0)
    light.light_energy = 2.2
    stage.add_child(light)
    var ambient := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("293b49")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("c9d4de")
    env.ambient_light_energy = 1.15
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    ambient.environment = env
    stage.add_child(ambient)
    _primitive(stage, "cylinder", Vector3(0, -0.12, 0), Vector3(1.9, 0.22, 1.9), Color("566071"))
    _primitive(stage, "cylinder", Vector3(0, -0.005, 0), Vector3(1.50, 0.06, 1.50), Color("ad9b75"), 0.25)
    var fill_light := OmniLight3D.new()
    fill_light.position = Vector3(1.9, 2.5, -2.0)
    fill_light.light_color = Color("efd5b1")
    fill_light.light_energy = 1.2
    fill_light.omni_range = 8.0
    stage.add_child(fill_light)
    preview_root = Node3D.new()
    stage.add_child(preview_root)
    _update_preview()

func _update_preview() -> void:
    if not is_instance_valid(preview_root):
        return
    preview_root.rotation.y = 0.0
    for child in preview_root.get_children():
        preview_root.remove_child(child)
        child.queue_free()
    imported_preview_animation = null
    var model := _build_character(preview_root, DATA.CLASSES[chosen_class]["color"], "preview")
    model.rotation.y = -0.20
    if is_instance_valid(creator_name):
        creator_name.text = "%s · %s" % [DATA.CLASSES[chosen_class]["name"], DATA.CLASSES[chosen_class]["region"]]

func _choose_class(id: String) -> void:
    chosen_class = id
    _load_class_appearance(id)
    gender_select.select(int(appearance["gender"]))
    face_select.select(int(appearance["face"]))
    hair_select.select(int(appearance["hair"]))
    _update_preview()

func _change_gender(i: int) -> void:
    appearance["gender"] = i
    _update_preview()

func _change_face(i: int) -> void:
    appearance["face"] = i
    _update_preview()

func _change_hair(i: int) -> void:
    appearance["hair"] = i
    _update_preview()

func _start_chosen_game() -> void:
    _start_game(chosen_class)

func _show_title() -> void:
    overlay.visible = true
    title_screen.visible = true
    creator_screen.visible = false
    if is_instance_valid(creator_preview):
        creator_preview.render_target_update_mode = SubViewport.UPDATE_DISABLED
    hud.visible = false
    game_running = false

func _show_creator() -> void:
    title_screen.visible = false
    creator_screen.visible = true
    if is_instance_valid(creator_preview):
        creator_preview.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    _choose_class(chosen_class)



# --- PALAGOS 0.8: persistent inventory, character design, merchants and audio ---
func _setup_music() -> void:
    music_player = AudioStreamPlayer.new()
    music_player.name = "PalagosSoundtrack"
    add_child(music_player)
    music_player.stream = load("res://audio/Legends_of_the_Enchanted_Realm.mp3")
    music_player.finished.connect(_restart_music)
    _load_audio_settings()
    _apply_music_volume()
    music_player.play()

func _restart_music() -> void:
    if is_instance_valid(music_player) and music_player.stream != null:
        music_player.play()

func _load_audio_settings() -> void:
    var path := "user://palagos_audio.json"
    if not FileAccess.file_exists(path):
        return
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return
    var settings = JSON.parse_string(file.get_as_text())
    if settings is Dictionary:
        music_level = clampf(float(settings.get("volume", 0.55)), 0.0, 1.0)
        music_muted = bool(settings.get("muted", false))

func _save_audio_settings() -> void:
    var file := FileAccess.open("user://palagos_audio.json", FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify({"volume":music_level, "muted":music_muted}))

func _apply_music_volume() -> void:
    if not is_instance_valid(music_player):
        return
    music_player.volume_db = -80.0 if music_muted or music_level <= 0.001 else linear_to_db(music_level)
    if is_instance_valid(volume_label):
        volume_label.text = "Musiklautstärke: %d %%" % roundi(music_level * 100.0)

func _set_music_volume(value: float) -> void:
    music_level = value
    _apply_music_volume()
    _save_audio_settings()

func _set_music_muted(enabled: bool) -> void:
    music_muted = enabled
    _apply_music_volume()
    _save_audio_settings()

func _load_camera_settings() -> void:
    if not FileAccess.file_exists("user://palagos_camera.json"):
        return
    var file := FileAccess.open("user://palagos_camera.json", FileAccess.READ)
    if file == null:
        return
    var data = JSON.parse_string(file.get_as_text())
    if data is Dictionary:
        # Pre-fix saved horizontal inversion flags were based on wrong yaw signs.
        camera_invert_x = bool(data.get("invert_x", false)) if int(data.get("camera_axis_version", 0)) >= 2 else false
        camera_invert_y = bool(data.get("invert_y", false))

func _save_camera_settings() -> void:
    var file := FileAccess.open("user://palagos_camera.json", FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify({"invert_x":camera_invert_x, "invert_y":camera_invert_y, "camera_axis_version":2}))

func _set_camera_invert_x(value: bool) -> void:
    camera_invert_x = value
    _save_camera_settings()

func _set_camera_invert_y(value: bool) -> void:
    camera_invert_y = value
    _save_camera_settings()

func _apply_camera_drag(delta_motion: Vector2) -> void:
    # Rightward swipe = look right; upward swipe = look up by default.
    camera_yaw += delta_motion.x * (0.006 if camera_invert_x else -0.006)
    camera_pitch = clampf(camera_pitch + delta_motion.y * (0.003 if camera_invert_y else -0.003), -0.75, 0.60)

func _setup_options(parent: Control) -> void:
    options_panel = PanelContainer.new()
    options_panel.anchor_left = 0.26
    options_panel.anchor_right = 0.74
    options_panel.anchor_top = 0.16
    options_panel.anchor_bottom = 0.84
    parent.add_child(options_panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 16)
    options_panel.add_child(box)
    var title := _label(box, "OPTIONEN · PALAGOS", 24)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    volume_label = _label(box, "Musiklautstärke: 55 %", 19)
    volume_slider = HSlider.new()
    volume_slider.min_value = 0
    volume_slider.max_value = 1
    volume_slider.step = 0.01
    volume_slider.value = music_level
    volume_slider.custom_minimum_size = Vector2(360, 36)
    volume_slider.value_changed.connect(_set_music_volume)
    box.add_child(volume_slider)
    mute_check = CheckButton.new()
    mute_check.text = "Musik stummschalten"
    mute_check.button_pressed = music_muted
    mute_check.toggled.connect(_set_music_muted)
    box.add_child(mute_check)
    var invert_h := CheckButton.new()
    invert_h.text = "Kamera horizontal umkehren"
    invert_h.button_pressed = camera_invert_x
    invert_h.toggled.connect(_set_camera_invert_x)
    box.add_child(invert_h)
    var invert_v := CheckButton.new()
    invert_v.text = "Kamera vertikal umkehren"
    invert_v.button_pressed = camera_invert_y
    invert_v.toggled.connect(_set_camera_invert_y)
    box.add_child(invert_v)
    var notice := _label(box, "Legends of the Enchanted Realm · Hintergrundmusik", 14)
    notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var close := Button.new()
    close.text = "SCHLIESSEN"
    close.custom_minimum_size.y = 46
    close.pressed.connect(_close_all_panels)
    box.add_child(close)
    options_panel.visible = false
    _apply_music_volume()

func _toggle_options() -> void:
    var opening := not options_panel.visible
    _close_all_panels()
    if opening:
        options_panel.visible = true
        volume_slider.value = music_level
        mute_check.button_pressed = music_muted

func _load_class_appearance(id: String) -> void:
    appearance = {"gender":0, "face":0, "hair":0}
    var file_path := SAVE_PREFIX + id + ".json"
    if not FileAccess.file_exists(file_path):
        return
    var file := FileAccess.open(file_path, FileAccess.READ)
    if file == null:
        return
    var loaded = JSON.parse_string(file.get_as_text())
    if loaded is Dictionary:
        var choice: Dictionary = loaded.get("appearance", {})
        appearance["gender"] = clampi(int(choice.get("gender", 0)), 0, 1)
        appearance["face"] = clampi(int(choice.get("face", 0)), 0, 3)
        appearance["hair"] = clampi(int(choice.get("hair", 0)), 0, 3)

func _init_items() -> void:
    gold = 140
    bag.clear()
    for index in range(ITEMS.BAG_SIZE):
        bag.append({})
    gear.clear()
    for key in ITEMS.EQUIPMENT_SLOTS:
        gear[key] = ""
    gear["weapon"] = ITEMS.starter_weapon(current_class)
    _add_item("heal_small", 3)

func _gear_stat(stat: String) -> int:
    var sum := 0
    for key in ITEMS.EQUIPMENT_SLOTS:
        var item_id: String = str(gear.get(key, ""))
        if ITEMS.ITEMS.has(item_id):
            sum += int(ITEMS.ITEMS[item_id].get(stat, 0))
    return sum

func _bag_has_room(item_id: String, count: int) -> bool:
    if not ITEMS.ITEMS.has(item_id) or count < 1:
        return false
    var max_stack := int(ITEMS.ITEMS[item_id]["stack"])
    var free_space := 0
    for slot in bag:
        if slot.is_empty():
            free_space += max_stack
        elif str(slot.get("id", "")) == item_id:
            free_space += maxi(0, max_stack - int(slot.get("qty", 0)))
    return free_space >= count

func _add_item(item_id: String, count: int = 1) -> bool:
    if not _bag_has_room(item_id, count):
        return false
    var remaining := count
    var max_stack := int(ITEMS.ITEMS[item_id]["stack"])
    for i in range(bag.size()):
        if remaining <= 0:
            break
        if bag[i].get("id", "") == item_id:
            var available := max_stack - int(bag[i]["qty"])
            var amount := mini(available, remaining)
            bag[i]["qty"] = int(bag[i]["qty"]) + amount
            remaining -= amount
    for i in range(bag.size()):
        if remaining <= 0:
            break
        if bag[i].is_empty():
            var amount := mini(max_stack, remaining)
            bag[i] = {"id":item_id, "qty":amount}
            remaining -= amount
    return remaining == 0

func _remove_slot(i: int, count: int = 1) -> void:
    if i < 0 or i >= bag.size() or bag[i].is_empty():
        return
    var rest := int(bag[i].get("qty", 0)) - count
    if rest <= 0:
        bag[i] = {}
    else:
        bag[i]["qty"] = rest

func _equip_bag_slot(i: int) -> void:
    if i < 0 or i >= bag.size() or bag[i].is_empty():
        return
    var item_id := str(bag[i]["id"])
    var item: Dictionary = ITEMS.ITEMS[item_id]
    if not item.has("slot"):
        if item_id == "heal_small":
            if hp < _max_hp():
                _heal(45.0)
                _remove_slot(i)
        elif item_id == "heal_large":
            if hp < _max_hp():
                _heal(95.0)
                _remove_slot(i)
        elif item_id == "mana_draught":
            if mana < 260.0:
                mana = minf(260.0, mana + 65.0)
                _remove_slot(i)
        else:
            _notify("Material kann später zum Handwerk verwendet werden.")
    else:
        var allowed: Array = item.get("allowed", [])
        if not allowed.is_empty() and not allowed.has(current_class):
            _notify("Diese Waffe passt nicht zu deiner Klasse.")
            return
        var equip_slot := str(item["slot"])
        var previous_id := str(gear.get(equip_slot, ""))
        _remove_slot(i)
        gear[equip_slot] = item_id
        if previous_id != "":
            _add_item(previous_id, 1)
        hp = minf(hp, _max_hp())
        _notify("Ausgerüstet: " + str(item["name"]))
    _save_game()
    _refresh_visible_weapon()
    _refresh_inventory()
    _refresh_gear()

func _unequip_item(slot: String) -> void:
    var old_id := str(gear.get(slot, ""))
    if old_id == "":
        return
    if not _add_item(old_id):
        _notify("Inventar voll.")
        return
    gear[slot] = ""
    hp = minf(hp, _max_hp())
    _save_game()
    _refresh_visible_weapon()
    _refresh_gear()
    _refresh_inventory()

func _buy_item(item_id: String) -> void:
    var item: Dictionary = ITEMS.ITEMS[item_id]
    var price := int(item["price"])
    if gold < price:
        _notify("Nicht genug Gold.")
        return
    if not _add_item(item_id):
        _notify("Das Inventar ist voll.")
        return
    gold -= price
    _save_game()
    _refresh_shop()
    _refresh_inventory()

func _sell_item(i: int) -> void:
    if i < 0 or i >= bag.size() or bag[i].is_empty():
        return
    var item_id := str(bag[i]["id"])
    gold += int(ITEMS.ITEMS[item_id]["sell"])
    _remove_slot(i)
    _save_game()
    _refresh_shop()
    _refresh_inventory()

func _build_vendors() -> void:
    vendor_npcs.clear()
    var shop_types := ["weapon", "armor", "supplies"]
    var vendor_colors := [Color("b7875e"), Color("8c9fbd"), Color("7aab80")]
    for i in range(3):
        var stall := Node3D.new()
        var sx := -9.0 + float(i) * 6.2
        stall.position = Vector3(sx, _terrain_height(sx, -9.0), -9.0)
        active_zone.add_child(stall)
        _primitive(stall, "box", Vector3(0, 0.8, 0.45), Vector3(3.1, 1.1, 1.65), Color("69503f"))
        _primitive(stall, "box", Vector3(0, 2.1, 0.45), Vector3(3.65, 0.25, 2.2), Color("3d3939"))
        var person := _build_character(active_zone, vendor_colors[i], "merchant")
        person.position = Vector3(stall.position.x, _terrain_height(stall.position.x, stall.position.z + 1.85), stall.position.z + 1.85)
        person.rotation.y = 0.2
        var sign := Label3D.new()
        sign.text = str(ITEMS.MERCHANTS[shop_types[i]]["name"])
        sign.position = Vector3(0, 2.85, 0)
        sign.font_size = 36
        sign.pixel_size = 0.007
        sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        person.add_child(sign)
        vendor_npcs.append({"node":person, "type":shop_types[i]})

func _build_pop_panel(parent: Control, heading: String) -> Dictionary:
    var panel := PanelContainer.new()
    panel.anchor_left = 0.17
    panel.anchor_right = 0.83
    panel.anchor_top = 0.09
    panel.anchor_bottom = 0.89
    parent.add_child(panel)
    var wrapper := VBoxContainer.new()
    wrapper.add_theme_constant_override("separation", 9)
    panel.add_child(wrapper)
    var top := HBoxContainer.new()
    wrapper.add_child(top)
    var label := _label(top, heading, 23)
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var close := Button.new()
    close.text = "Schließen"
    close.pressed.connect(_close_all_panels)
    top.add_child(close)
    var content := ScrollContainer.new()
    content.size_flags_vertical = Control.SIZE_EXPAND_FILL
    wrapper.add_child(content)
    panel.visible = false
    return {"panel":panel, "content":content, "wrapper":wrapper}

func _setup_system_panels(parent: Control) -> void:
    var inventory_ui := _build_pop_panel(parent, "INVENTAR · 24 PLÄTZE")
    inventory_panel = inventory_ui["panel"]
    var inventory_body := VBoxContainer.new()
    inventory_body.add_theme_constant_override("separation", 8)
    inventory_ui["content"].add_child(inventory_body)
    inventory_info = _label(inventory_body, "Gegenstand auswählen oder benutzen", 16)
    inventory_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    inventory_action = Button.new()
    inventory_action.text = "Bitte einen Gegenstand auswählen"
    inventory_action.custom_minimum_size.y = 46
    inventory_action.disabled = true
    inventory_action.pressed.connect(_use_selected_item)
    inventory_body.add_child(inventory_action)
    inventory_grid = GridContainer.new()
    inventory_grid.columns = 4
    inventory_grid.add_theme_constant_override("h_separation", 8)
    inventory_grid.add_theme_constant_override("v_separation", 8)
    inventory_body.add_child(inventory_grid)

    var equip_ui := _build_pop_panel(parent, "AUSRÜSTUNG · CHARAKTER")
    gear_panel = equip_ui["panel"]
    gear_list = VBoxContainer.new()
    equip_ui["content"].add_child(gear_list)
    gear_stats = _label(gear_list, "", 16)

    var merchant_ui := _build_pop_panel(parent, "HÄNDLER · KAUFEN / VERKAUFEN")
    shop_panel = merchant_ui["panel"]
    var shop_wrapper := VBoxContainer.new()
    merchant_ui["content"].add_child(shop_wrapper)
    shop_text = _label(shop_wrapper, "", 17)
    shop_grid = VBoxContainer.new()
    shop_grid.add_theme_constant_override("separation", 7)
    shop_wrapper.add_child(shop_grid)

func _any_panel_open() -> bool:
    return dialogue_open or talent_open or inventory_panel.visible or gear_panel.visible or shop_panel.visible or options_panel.visible

func _close_all_panels() -> void:
    dialogue_open = false
    talent_open = false
    dialog_panel.visible = false
    talent_panel.visible = false
    inventory_panel.visible = false
    gear_panel.visible = false
    shop_panel.visible = false
    options_panel.visible = false

func _toggle_inventory() -> void:
    if not game_running:
        return
    var opening := not inventory_panel.visible
    _close_all_panels()
    if opening:
        selected_bag_slot = -1
        inventory_panel.visible = true
        _refresh_inventory()

func _refresh_inventory() -> void:
    if not is_instance_valid(inventory_grid):
        return
    for old in inventory_grid.get_children():
        old.queue_free()
    inventory_info.text = "Gold: %d · Wähle einen Gegenstand für Details." % gold
    inventory_action.disabled = true
    inventory_action.text = "Gegenstand auswählen"
    if selected_bag_slot >= 0 and selected_bag_slot < bag.size() and not bag[selected_bag_slot].is_empty():
        var item_id := str(bag[selected_bag_slot]["id"])
        inventory_info.text = "Gold: %d · %s" % [gold, _item_details(item_id)]
        inventory_action.text = "AUSRÜSTEN / BENUTZEN"
        inventory_action.disabled = false
    for i in range(bag.size()):
        var cell := Button.new()
        cell.custom_minimum_size = Vector2(148, 58)
        if bag[i].is_empty():
            cell.text = "%02d · Frei" % (i + 1)
            cell.disabled = true
        else:
            var id := str(bag[i]["id"])
            var item: Dictionary = ITEMS.ITEMS[id]
            cell.text = "%02d · %s\n×%d" % [i + 1, str(item["name"]), int(bag[i]["qty"])]
            cell.tooltip_text = _item_details(id)
            cell.pressed.connect(_select_bag_item.bind(i))
        inventory_grid.add_child(cell)

func _select_bag_item(i: int) -> void:
    selected_bag_slot = i
    _refresh_inventory()

func _use_selected_item() -> void:
    if selected_bag_slot >= 0:
        _equip_bag_slot(selected_bag_slot)
        selected_bag_slot = -1
        _refresh_inventory()

func _item_details(item_id: String) -> String:
    var item: Dictionary = ITEMS.ITEMS[item_id]
    var result := str(item["name"]) + " · " + str(item["desc"])
    if item.has("slot"):
        result += " | Angriff +%d | Leben +%d" % [int(item.get("attack", 0)), int(item.get("health", 0))]
    return result

func _refresh_gear() -> void:
    if not is_instance_valid(gear_list):
        return
    for child in gear_list.get_children():
        if child != gear_stats:
            child.queue_free()
    gear_stats.text = "%s · Stufe %d\nAngriff durch Ausrüstung: +%d · Zusatzleben: +%d" % [cfg()["name"], level, _gear_stat("attack"), _gear_stat("health")]
    for slot in ITEMS.EQUIPMENT_SLOTS:
        var item_id := str(gear.get(slot, ""))
        var btn := Button.new()
        btn.custom_minimum_size.y = 40
        btn.text = "%s: %s%s" % [str(ITEMS.SLOT_NAMES[slot]), str(ITEMS.ITEMS[item_id]["name"]) if ITEMS.ITEMS.has(item_id) else "Leer", " · Ablegen" if item_id != "" else ""]
        btn.disabled = item_id == ""
        btn.pressed.connect(_unequip_item.bind(slot))
        gear_list.add_child(btn)

func _toggle_gear() -> void:
    if not game_running:
        return
    var opening := not gear_panel.visible
    _close_all_panels()
    if opening:
        gear_panel.visible = true
        _refresh_gear()

func _open_shop(merchant_type: String) -> void:
    _close_all_panels()
    active_merchant = merchant_type
    shop_panel.visible = true
    _refresh_shop()

func _refresh_shop() -> void:
    if active_merchant == "" or not is_instance_valid(shop_grid):
        return
    for old in shop_grid.get_children():
        old.queue_free()
    var vendor: Dictionary = ITEMS.MERCHANTS[active_merchant]
    shop_text.text = "%s · Du besitzt %d Gold.\nKaufen:" % [str(vendor["name"]), gold]
    for id in vendor["items"]:
        var item: Dictionary = ITEMS.ITEMS[id]
        var button := Button.new()
        button.custom_minimum_size.y = 46
        button.text = "%s · %d Gold · %s" % [str(item["name"]), int(item["price"]), _item_details(id)]
        button.pressed.connect(_buy_item.bind(id))
        shop_grid.add_child(button)
    _label(shop_grid, "Verkaufen (jeweils 1 Gegenstand):", 17)
    for i in range(bag.size()):
        if bag[i].is_empty():
            continue
        var id := str(bag[i]["id"])
        var sell_btn := Button.new()
        sell_btn.text = "%s ×%d · +%d Gold" % [str(ITEMS.ITEMS[id]["name"]), int(bag[i]["qty"]), int(ITEMS.ITEMS[id]["sell"])]
        sell_btn.pressed.connect(_sell_item.bind(i))
        shop_grid.add_child(sell_btn)

func _setup_dialogs(parent: Control) -> void:
    dialog_panel = PanelContainer.new()
    dialog_panel.anchor_left = 0.27
    dialog_panel.anchor_right = 0.73
    dialog_panel.anchor_top = 0.22
    dialog_panel.anchor_bottom = 0.77
    parent.add_child(dialog_panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 15)
    dialog_panel.add_child(vb)
    dialog_title = _label(vb, "Seryn", 24)
    dialog_text = _label(vb, "", 16)
    dialog_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    dialog_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
    var row := HBoxContainer.new()
    vb.add_child(row)
    dialog_accept = Button.new()
    dialog_accept.text = "Quest annehmen"
    dialog_accept.pressed.connect(_accept_quest)
    row.add_child(dialog_accept)
    dialog_decline = Button.new()
    dialog_decline.text = "Ablehnen / Schließen"
    dialog_decline.pressed.connect(_close_dialog)
    row.add_child(dialog_decline)
    dialog_panel.visible = false
    talent_panel = PanelContainer.new()
    talent_panel.anchor_left = 0.25
    talent_panel.anchor_right = 0.75
    talent_panel.anchor_top = 0.15
    talent_panel.anchor_bottom = 0.81
    parent.add_child(talent_panel)
    var tv := VBoxContainer.new()
    talent_panel.add_child(tv)
    talent_text = _label(tv, "Talente", 21)
    for i in range(3):
        var b := Button.new()
        b.custom_minimum_size.y = 52
        b.pressed.connect(_spend_talent.bind(i))
        tv.add_child(b)
        talent_buttons.append(b)
    var close := Button.new()
    close.text = "Schließen"
    close.pressed.connect(_toggle_talents)
    tv.add_child(close)
    talent_panel.visible = false

func _start_game(id: String) -> void:
    current_class = id
    level = 1
    xp = 0
    talents = [0, 0, 0]
    hp = float(cfg()["hp"])
    mana = 260.0
    resource = 100.0
    cooldowns = [0.0, 0.0, 0.0]
    quest_index = 0
    quest_progress = 0
    quest_accepted = false
    shared_world = false
    _init_items()
    selected_enemy = -1
    cast_slot = -1
    attack_motion_time = 0.0
    attack_motion_kind = ""
    overlay.visible = false
    if is_instance_valid(creator_preview):
        creator_preview.render_target_update_mode = SubViewport.UPDATE_DISABLED
    hud.visible = true
    if is_instance_valid(hero):
        hero.queue_free()
    imported_model_ready = false
    imported_hero_animation = null
    imported_hero_model = null
    hero = _build_character(self, cfg()["color"], "hero")
    _generate_zone()
    game_running = true
    _restore_progress(id)
    _refresh_visible_weapon()
    _refresh_hud()
    _notify("Sprich mit Seryn, indem du sie antippst.")

func _restore_progress(id: String) -> void:
    if not FileAccess.file_exists(_save_path()):
        return
    var f := FileAccess.open(_save_path(), FileAccess.READ)
    if f == null:
        return
    var parse = JSON.parse_string(f.get_as_text())
    if typeof(parse) != TYPE_DICTIONARY:
        return
    var save: Dictionary = parse
    if str(save.get("class", "")) != id:
        return
    level = clampi(int(save.get("level", 1)), 1, 20)
    xp = maxi(0, int(save.get("xp", 0)))
    quest_index = clampi(int(save.get("quest", 0)), 0, 3)
    quest_progress = maxi(0, int(save.get("progress", 0)))
    quest_accepted = bool(save.get("accepted", false))
    var t: Array = save.get("talents", [0, 0, 0])
    if t.size() == 3:
        talents = [clampi(int(t[0]), 0, 3), clampi(int(t[1]), 0, 3), clampi(int(t[2]), 0, 3)]
    gold = maxi(0, int(save.get("gold", gold)))
    var saved_bag: Array = save.get("bag", [])
    var saved_gear: Dictionary = save.get("gear", {})
    if saved_bag.size() == ITEMS.BAG_SIZE:
        bag.clear()
        for slot in saved_bag:
            if slot is Dictionary and ITEMS.ITEMS.has(str(slot.get("id", ""))):
                bag.append({"id":str(slot["id"]), "qty":clampi(int(slot.get("qty", 1)), 1, 20)})
            else:
                bag.append({})
    for key in ITEMS.EQUIPMENT_SLOTS:
        var equip_id: String = str(saved_gear.get(key, ""))
        if ITEMS.ITEMS.has(equip_id) and str(ITEMS.ITEMS[equip_id].get("slot", "")) == key:
            gear[key] = equip_id
    hp = _max_hp()
    mana = 260.0
    if bool(save.get("shared", false)) and level >= 10:
        shared_world = true
        _generate_zone()

func _save_game() -> void:
    if not game_running:
        return
    var content := {"class":current_class, "level":level, "xp":xp, "quest":quest_index, "progress":quest_progress, "accepted":quest_accepted, "talents":talents, "shared":shared_world, "gold":gold, "bag":bag, "gear":gear, "appearance":appearance}
    var f := FileAccess.open(_save_path(), FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify(content))

func _max_hp() -> float:
    return float(cfg()["hp"]) + float(level - 1) * 9.0 + float(_gear_stat("health"))

func _xp_needed() -> int:
    return 90 + (level - 1) * 35

func _talent_points() -> int:
    return maxi(0, level - 1 - talents[0] - talents[1] - talents[2])

func _give_xp(amount: int) -> void:
    if level >= 20:
        xp = 0
        return
    xp += amount
    while level < 20 and xp >= _xp_needed():
        xp -= _xp_needed()
        level += 1
        hp = _max_hp()
        mana = 260.0
        _notify("Stufe %d! Neuer Talentpunkt." % level)
        if level == 10:
            _notify("Stufe 10! Die gemeinsame Spielwelt ist jetzt offen.")
    if level >= 20:
        xp = 0
    _save_game()

func _refresh_hud() -> void:
    if not game_running:
        return
    level_label.text = "%s · Stufe %d · EP %s · %d Gold" % [cfg()["name"], level, "MAX" if level >= 20 else "%d/%d" % [xp, _xp_needed()], gold]
    hp_bar.max_value = _max_hp()
    hp_bar.value = hp
    hp_bar.tooltip_text = "Leben %.0f / %.0f" % [hp, _max_hp()]
    mana_bar.max_value = 260 if float(cfg()["cast"]) > 0 else 100
    mana_bar.value = mana if float(cfg()["cast"]) > 0 else resource
    mana_bar.tooltip_text = "Mana %.0f/260" % mana if float(cfg()["cast"]) > 0 else "Ausdauer %.0f/100" % resource
    region_label.text = "Zone: Die Kernlande" if shared_world else "Startgebiet: " + str(cfg()["region"])
    var quests: Array[Dictionary] = DATA.quests_for(current_class)
    if shared_world:
        quest_label.text = "Gemeinsame Welt · erste Erkundung"
    elif quest_index >= quests.size():
        quest_label.text = "Einführung abgeschlossen (weitere Quests folgen)"
    else:
        var q: Dictionary = quests[quest_index]
        quest_label.text = str(q["title"]) + ": %d/%d" % [quest_progress, int(q["count"])] if quest_accepted else "Tippe Seryn an, um die Quest anzunehmen."
    var display_names := [str(cfg()["basic"]), str(cfg()["first"]), str(cfg()["second"])]
    for i in range(3):
        var remaining: float = cooldowns[i]
        spell_buttons[i].text = display_names[i] + ("\n%.1fs" % remaining if remaining > 0.1 else "\n[%d]" % (i + 1))
        spell_buttons[i].disabled = hp <= 0 or (cast_slot != -1) or remaining > 0.1
    target_label.text = "Ziel: " + ("%s · %d / %d HP" % [str(enemies[selected_enemy]["name"]), int(enemies[selected_enemy]["hp"]), int(enemies[selected_enemy]["max_hp"])] if _target_valid(selected_enemy) else "kein Ziel · Gegner antippen")
    cast_bar.visible = cast_slot >= 0
    cast_label.text = "Wirken: " + ([str(cfg()["basic"]),str(cfg()["first"]),str(cfg()["second"])][cast_slot] if cast_slot >= 0 else "")
    if cast_slot >= 0 and cast_total > 0:
        cast_bar.value = 1.0 - cast_remaining / cast_total
    world_button.disabled = level < 10
    talent_button.text = "Talente (%d)" % _talent_points()

func _target_valid(id: int) -> bool:
    return id >= 0 and id < enemies.size() and bool(enemies[id]["alive"])

func _nearest_enemy(radius: float) -> int:
    var nearest := -1
    var nearest_dist := radius
    for i in range(enemies.size()):
        if not bool(enemies[i]["alive"]):
            continue
        var d: float = hero.position.distance_to(enemies[i]["node"].position)
        if d < nearest_dist:
            nearest_dist = d
            nearest = i
    return nearest

func _find_target(range_value: float) -> int:
    if _target_valid(selected_enemy):
        if hero.position.distance_to(enemies[selected_enemy]["node"].position) < range_value:
            return selected_enemy
        return -1
    return _nearest_enemy(range_value)

func _activate_slot(slot: int) -> void:
    if not game_running or _any_panel_open() or hp <= 0:
        return
    if cast_slot != -1 or cooldowns[slot] > 0:
        return
    var cost: int = cfg()["costs"][slot]
    var caster: bool = float(cfg()["cast"]) > 0
    if (mana if caster else resource) < cost:
        _notify("Nicht genug Mana." if caster else "Nicht genug Ausdauer.")
        return
    var range_value: float = cfg()["range"]
    var target := _find_target(range_value)
    var needs_target := slot == 0 or (slot == 1 and current_class in ["jaeger", "magier", "druide"])
    if needs_target and target < 0:
        _notify("Kein Gegner in Reichweite. Tippe ihn zum Anvisieren an.")
        return
    if current_class == "jaeger" and slot in [0, 1]:
        # A deliberate bow draw gives a visible nock -> pull -> release cycle.
        cast_slot = slot
        cast_remaining = 0.78 if slot == 0 else 1.05
        cast_total = cast_remaining
        cast_target = target
        in_combat_timer = COMBAT_SECONDS
        _face_target(target)
        _begin_attack_motion(slot, "bow_draw", cast_remaining)
        return
    if caster:
        var duration: float = cfg()["cast"] if slot == 0 else 1.35
        # Instant defensive abilities are allowed but their offensive spells cast.
        if slot == 2:
            duration = 0
        if duration > 0:
            cast_slot = slot
            cast_remaining = duration
            cast_total = duration
            cast_target = target
            in_combat_timer = COMBAT_SECONDS
            _face_target(target)
            _begin_attack_motion(slot, "spell_channel", duration)
            _spell_effect(hero.position + Vector3(0, 1.2, 0), cfg()["color"], 0.38)
            return
    _execute_slot(slot, target)

func _execute_slot(slot: int, target: int) -> void:
    var caster: bool = float(cfg()["cast"]) > 0
    var cost: int = cfg()["costs"][slot]
    if caster:
        if mana < cost:
            _notify("Nicht genug Mana")
            return
        mana -= cost
    else:
        if resource < cost:
            return
        resource -= cost
    cooldowns[slot] = cfg()["cooldowns"][slot]
    in_combat_timer = COMBAT_SECONDS
    _face_target(target)
    if current_class in ["krieger", "paladin"]:
        _begin_attack_motion(slot, "sword", 0.58)
    elif current_class == "jaeger":
        _begin_attack_motion(slot, "bow_release", 0.42)
    else:
        _begin_attack_motion(slot, "cast_release", 0.54)
    var power := 1.0 + float(level - 1) * 0.12
    var strike_boost := 1.0 + float(talents[0]) * 0.12
    var spell_boost := 1.0 + float(talents[1]) * 0.18
    var utility_boost := 1.0 + float(talents[2]) * 0.15
    if slot == 0:
        var hit_power := float(cfg()["damage"]) * strike_boost + float(level - 1) * 3.3
        if current_class in ["jaeger", "magier", "priester", "druide"]:
            _launch_spell_missile(target, hit_power, slot)
        else:
            _damage_enemy(target, hit_power)
        if current_class == "paladin":
            _heal(2.0)
    elif slot == 1:
        match current_class:
            "krieger":
                _damage_near(hero.position, 5.0, 44.0 * power * spell_boost)
            "jaeger":
                _launch_spell_missile(target, 48.0 * power * spell_boost, slot)
            "magier":
                _launch_spell_missile(target, 61.0 * power * spell_boost, slot)
            "priester":
                _damage_near(hero.position, 7.0, 38.0 * power * spell_boost)
                _heal(27.0 * power)
            "druide":
                _launch_spell_missile(target, 42.0 * power * spell_boost, slot)
                if _target_valid(target):
                    enemies[target]["stunned"] = 2.5
            "paladin":
                _damage_near(hero.position, 5.0, 37.0 * power * spell_boost)
    elif slot == 2:
        match current_class:
            "krieger":
                buffs["damage"] = 10.0 * utility_boost
                _heal(14.0 * utility_boost)
            "jaeger":
                buffs["damage"] = 11.0 * utility_boost
            "magier":
                _damage_near(hero.position, 5.2, 14.0 * power * utility_boost, 2.0)
            "priester":
                _heal(60.0 * utility_boost)
                buffs["shield"] = 4.0
            "druide":
                _heal(42.0 * utility_boost)
                buffs["hot"] = 10.0 * utility_boost
            "paladin":
                _heal(34.0 * utility_boost)
                buffs["shield"] = 2.0
    var effect_point: Vector3 = hero.position
    if _target_valid(target):
        effect_point = enemies[target]["node"].position
    var hue: Color = cfg()["color"]
    if current_class == "magier" and slot == 1:
        hue = Color("ff7733")
    elif current_class == "magier" and slot == 2:
        hue = Color("65d7f8")
    elif current_class == "druide":
        hue = Color("64db80")
    if not (slot == 0 and current_class in ["jaeger", "magier", "priester", "druide"]) and not (slot == 1 and current_class in ["jaeger", "magier", "druide"]):
        _spell_effect(effect_point + Vector3(0, 1, 0), hue, 0.5 if slot == 0 else 1.15)
    _save_game()

func _damage_near(where: Vector3, radius: float, amount: float, stun: float = 0.0) -> void:
    for e in enemies:
        if bool(e["alive"]) and e["node"].position.distance_to(where) < radius:
            _damage_enemy(int(e["id"]), amount)
            e["stunned"] = maxf(float(e["stunned"]), stun)

func _damage_enemy(id: int, amount: float) -> void:
    if not _target_valid(id):
        return
    if float(buffs["damage"]) > 0.0:
        amount *= 1.22
    var enemy: Dictionary = enemies[id]
    var damage := maxf(1.0, roundf(amount + float(_gear_stat("attack"))))
    enemy["hp"] = maxf(0.0, float(enemy["hp"]) - damage)
    enemy["body"].rotation.z = rng.randf_range(-0.10, 0.10)
    _float_number("-%d" % int(damage), enemy["node"].position + Vector3(0, 2.1, 0), Color("e9d477"))
    if float(enemy["hp"]) <= 0:
        enemy["alive"] = false
        enemy["respawn"] = ENEMY_RESPAWN
        enemy["node"].visible = false
        if selected_enemy == id:
            selected_enemy = -1
        _give_xp(33)
        gold += rng.randi_range(3, 9)
        if rng.randf() < 0.42:
            var loot_id := "core_shard" if rng.randf() < 0.25 else "wolf_fang"
            if _add_item(loot_id):
                _notify("Beute: " + str(ITEMS.ITEMS[loot_id]["name"]))
        _save_game()
        var quests: Array[Dictionary] = DATA.quests_for(current_class)
        if quest_accepted and quest_index < quests.size() and not shared_world:
            quest_progress = mini(int(quests[quest_index]["count"]), quest_progress + 1)
            _save_game()

func _heal(amount: float) -> void:
    var old_hp := hp
    hp = minf(_max_hp(), hp + amount)
    if hp > old_hp:
        _float_number("+%d" % int(hp - old_hp), hero.position + Vector3(0, 2.6, 0), Color("72e59c"))

func _spell_effect(origin: Vector3, color: Color, size_multiplier: float) -> void:
    var effect := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radial_segments = 12
    sphere.rings = 6
    effect.mesh = sphere
    var effect_material := _make_material(color, 2.0)
    effect_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    effect.material_override = effect_material
    effect.position = origin
    var size_value := 0.18 + size_multiplier * 0.6
    effect.scale = Vector3.ONE * 0.09
    add_child(effect)
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(effect, "scale", Vector3.ONE * size_value, 0.38)
    tween.tween_property(effect_material, "albedo_color:a", 0.0, 0.42)
    tween.set_parallel(false)
    tween.tween_callback(effect.queue_free)

func _float_number(value: String, pos: Vector3, tint: Color) -> void:
    var number := Label3D.new()
    number.text = value
    number.font_size = 52
    number.pixel_size = 0.006
    number.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    number.modulate = tint
    number.position = pos
    add_child(number)
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(number, "position:y", pos.y + 1.45, 0.85)
    tween.tween_property(number, "modulate:a", 0.0, 0.85)
    tween.set_parallel(false)
    tween.tween_callback(number.queue_free)

func _process(delta: float) -> void:
    if is_instance_valid(preview_root) and is_instance_valid(creator_screen) and creator_screen.visible:
        preview_root.rotation.y += delta * 0.20
    if not game_running:
        return
    if message_timer > 0:
        message_timer -= delta
        if message_timer <= 0:
            msg_label.text = ""
    if not _any_panel_open() and hp > 0:
        _update_movement(delta)
        _update_combat(delta)
    _animate_weapon_frame(delta)
    _update_imported_avatar_animation()
    _update_missiles(delta)
    _update_camera(delta)
    _update_nameplates()
    _refresh_hud()

func _update_movement(delta: float) -> void:
    var input_axis := move_axis
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        input_axis.y -= 1
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        input_axis.y += 1
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        input_axis.x -= 1
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        input_axis.x += 1
    input_axis = input_axis.limit_length(1.0)
    imported_hero_moving = input_axis.length() > 0.09
    if input_axis.length() > 0.09:
        if cast_slot >= 0:
            cast_slot = -1
            _notify("Zauber durch Bewegung unterbrochen.")
        var forward := Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))
        var right := Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
        var direction := forward * -input_axis.y + right * input_axis.x
        var travel := direction.normalized() * delta * 4.75 * input_axis.length()
        # Physics prevents walking through houses, trees and large rocks.
        var hero_body := hero as CharacterBody3D
        if hero_body != null:
            hero_body.move_and_collide(travel)
        else:
            hero.position += travel
        hero.position.x = clampf(hero.position.x, -88.0, 88.0)
        hero.position.z = clampf(hero.position.z, -88.0, 88.0)
        hero.position.y = _terrain_height(hero.position.x, hero.position.z)
        hero.rotation.y = atan2(-direction.x, -direction.z)
        walk_phase += delta * 11
    else:
        walk_phase += delta * 2
    var motion := minf(1.0, input_axis.length())
    if not hero_joints.is_empty():
        var casting := cast_slot >= 0
        for i in range(2):
            var phase: float = walk_phase + float(i) * PI
            var shoulder: Node3D = hero_joints["arms"][i]
            var elbow: Node3D = hero_joints["elbows"][i]
            var hip: Node3D = hero_joints["legs"][i]
            var knee: Node3D = hero_joints["knees"][i]
            var arm_target := -0.85 if casting else sin(phase) * 0.45 * motion
            shoulder.rotation.x = lerpf(shoulder.rotation.x, arm_target, minf(1.0, delta * 9.0))
            var arm_spread: float = 0.24 if i == 0 else -0.24
            shoulder.rotation.z = lerpf(shoulder.rotation.z, arm_spread if casting else 0.03, minf(1.0, delta * 7.0))
            elbow.rotation.x = lerpf(elbow.rotation.x, -0.68 if casting else 0.12 + maxf(0.0, sin(phase + 0.4)) * 0.32 * motion, minf(1.0, delta * 9.0))
            hip.rotation.x = lerpf(hip.rotation.x, -sin(phase) * 0.54 * motion, minf(1.0, delta * 10.0))
            knee.rotation.x = lerpf(knee.rotation.x, maxf(0.0, sin(phase)) * 0.70 * motion, minf(1.0, delta * 10.0))
        # Casting energy gradually accumulates around the hands; low particle budget for Android.
        if casting:
            cast_visual_clock -= delta
            if cast_visual_clock <= 0.0:
                cast_visual_clock = 0.20
                var arc_color: Color = cfg()["color"]
                _spell_effect(hero.position + Vector3(rng.randf_range(-0.8, 0.8), 1.2 + rng.randf_range(0, 1.0), rng.randf_range(-0.4, 0.4)), arc_color, 0.19)
        else:
            cast_visual_clock = 0.0
    for key in buffs.keys():
        buffs[key] = maxf(0.0, float(buffs[key]) - delta)
    if float(buffs["hot"]) > 0:
        _heal(delta * 3.2)
    if hp <= 0:
        return
    in_combat_timer = maxf(0.0, in_combat_timer - delta)
    if float(cfg()["cast"]) > 0:
        mana = minf(260, mana + delta * (1.0 if in_combat_timer > 0 else 3.5))
    else:
        resource = minf(100, resource + delta * (3.0 if in_combat_timer > 0 else 6.0))
    if in_combat_timer <= 0:
        hp = minf(_max_hp(), hp + delta * 3.4)

func _update_combat(delta: float) -> void:
    for i in range(3):
        cooldowns[i] = maxf(0.0, cooldowns[i] - delta)
    if cast_slot != -1:
        cast_remaining -= delta
        if cast_remaining <= 0:
            var finishing := cast_slot
            var aim := cast_target
            cast_slot = -1
            var offensive := finishing == 0 or (finishing == 1 and current_class in ["jaeger", "magier", "druide"])
            if offensive and not _target_valid(aim):
                _notify("Ziel nicht mehr verfügbar.")
            elif offensive and hero.position.distance_to(enemies[aim]["node"].position) > float(cfg()["range"]) + 0.5:
                _notify("Ziel außer Reichweite.")
            else:
                _execute_slot(finishing, aim)
    # Only two nearby monsters may engage at once; ranged classes do not get a
    # free 17-meter shooting lane, but new characters are not mobbed by all eight.
    var close_enemies: Array[Dictionary] = []
    for e in enemies:
        if bool(e["alive"]) and hero.position.distance_to(e["node"].position) < 18.0:
            close_enemies.append(e)
    close_enemies.sort_custom(_closer_enemy)
    var active_ids: Array[int] = []
    if _target_valid(selected_enemy) and hero.position.distance_to(enemies[selected_enemy]["node"].position) < 18.0:
        active_ids.append(selected_enemy)
    for e in close_enemies:
        if active_ids.size() >= 2:
            break
        if not active_ids.has(int(e["id"])):
            active_ids.append(int(e["id"]))
    for e in enemies:
        if not bool(e["alive"]):
            e["respawn"] = float(e["respawn"]) - delta
            if float(e["respawn"]) <= 0:
                e["hp"] = e["max_hp"]
                e["alive"] = true
                e["node"].visible = true
                e["node"].position = e["home"]
                e["stunned"] = 0.0
            continue
        e["stunned"] = maxf(0.0, float(e["stunned"]) - delta)
        var monster: Node3D = e["node"]
        var distance: float = hero.position.distance_to(monster.position)
        if active_ids.has(int(e["id"])):
            in_combat_timer = COMBAT_SECONDS
            if float(e["stunned"]) <= 0:
                if distance > 2.3:
                    var direction := (hero.position - monster.position).normalized()
                    monster.position += direction * delta * float(e["speed"])
                    monster.position.y = _terrain_height(monster.position.x, monster.position.z)
                    monster.look_at(Vector3(hero.position.x, monster.position.y + 0.8, hero.position.z), Vector3.UP)
                else:
                    e["attack_cd"] = float(e["attack_cd"]) - delta
                    if float(e["attack_cd"]) <= 0:
                        e["attack_cd"] = 2.5
                        if float(buffs["shield"]) <= 0:
                            var dmg := rng.randi_range(maxi(1, int(e["attack"]) - 1), int(e["attack"]) + 2)
                            hp = maxf(0.0, hp - dmg)
                            _float_number("-%d" % dmg, hero.position + Vector3(0, 2.6, 0), Color("f36b69"))
                            if hp <= 0:
                                _notify("Du wurdest besiegt. Öffne das Menü zur Wiederbelebung.")
        elif distance > 21.0:
            monster.position = monster.position.lerp(e["home"], minf(1, delta * 0.8))
            monster.position.y = _terrain_height(monster.position.x, monster.position.z)

func _closer_enemy(a: Dictionary, b: Dictionary) -> bool:
    return hero.position.distance_to(a["node"].position) < hero.position.distance_to(b["node"].position)

func _update_camera(delta: float) -> void:
    if not is_instance_valid(hero):
        return
    var direction := Vector3(-sin(camera_yaw), sin(camera_pitch), -cos(camera_yaw)).normalized()
    var desired := hero.position - direction * 8.0 + Vector3(0, 2.7, 0)
    var focus := hero.position + Vector3(0, 1.55, 0)
    var query := PhysicsRayQueryParameters3D.create(focus, desired, 4)
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.is_empty():
        desired = focus + (hit["position"] - focus) * 0.87
    camera.position = camera.position.lerp(desired, minf(1, delta * 12))
    camera.look_at(hero.position + Vector3(0, 1.55, 0), Vector3.UP)

func _update_nameplates() -> void:
    for i in range(enemies.size()):
        var plate: Control = nameplates[i]["panel"]
        var enemy: Dictionary = enemies[i]
        var pos: Vector3 = enemy["node"].position + Vector3(0, 2.35, 0)
        plate.visible = bool(enemy["alive"]) and not camera.is_position_behind(pos)
        if plate.visible:
            plate.position = camera.unproject_position(pos) - Vector2(53, 20)
            nameplates[i]["bar"].value = enemy["hp"]
            plate.modulate = Color("f6dc85") if i == selected_enemy else Color.WHITE

func _unhandled_key_input(event: InputEvent) -> void:
    if not (event is InputEventKey):
        return
    var key_event: InputEventKey = event
    if not key_event.pressed or key_event.echo or not game_running:
        return
    match key_event.keycode:
        KEY_1: _activate_slot(0)
        KEY_2: _activate_slot(1)
        KEY_3: _activate_slot(2)
        KEY_T: _toggle_talents()
        KEY_E: _open_dialog()
        KEY_ESCAPE: _toggle_menu()
        KEY_I: _toggle_inventory()
        KEY_C: _toggle_gear()
        KEY_O: _toggle_options()

func _unhandled_input(event: InputEvent) -> void:
    if not game_running:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.36 and event.position.y > get_viewport().get_visible_rect().size.y * 0.52:
                stick_id = event.index
                _set_stick(event.position)
            else:
                look_id = event.index
                look_last = event.position
                _select_world_at(event.position)
        else:
            if event.index == stick_id:
                stick_id = -1
                move_axis = Vector2.ZERO
                joystick_knob.position = Vector2(46, 46)
            if event.index == look_id:
                look_id = -1
    elif event is InputEventScreenDrag:
        if event.index == stick_id:
            _set_stick(event.position)
        elif event.index == look_id:
            var delta_motion: Vector2 = event.position - look_last
            _apply_camera_drag(delta_motion)
            look_last = event.position
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        _select_world_at(event.position)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        _apply_camera_drag(event.relative)

func _set_stick(pos: Vector2) -> void:
    var view_size := get_viewport().get_visible_rect().size
    var origin := Vector2(108, view_size.y - 105)
    var offset := (pos - origin).limit_length(50)
    move_axis = offset / 50.0
    joystick_knob.position = Vector2(46, 46) + offset

func _select_world_at(screen_pos: Vector2) -> void:
    if _any_panel_open():
        return
    # Screen projection avoids the physics-space access restrictions of an input callback.
    var npc_pos: Vector3 = npc.position + Vector3(0, 1.4, 0)
    for vendor in vendor_npcs:
        var seller: Node3D = vendor["node"]
        var seller_pos := seller.position + Vector3(0, 1.4, 0)
        if not camera.is_position_behind(seller_pos) and camera.unproject_position(seller_pos).distance_to(screen_pos) < 75.0:
            if hero.position.distance_to(seller.position) < 5.0:
                _open_shop(str(vendor["type"]))
            else:
                _notify("Gehe näher zum Händler.")
            return
    if not camera.is_position_behind(npc_pos) and camera.unproject_position(npc_pos).distance_to(screen_pos) < 65.0:
        if hero.position.distance_to(npc.position) < 5.0:
            _open_dialog()
        else:
            _notify("Gehe näher zu Seryn.")
        return
    var nearest := -1
    var nearest_screen := 67.0
    for i in range(enemies.size()):
        if not bool(enemies[i]["alive"]):
            continue
        var pos: Vector3 = enemies[i]["node"].position + Vector3(0, 1.25, 0)
        if camera.is_position_behind(pos):
            continue
        var distance_px := camera.unproject_position(pos).distance_to(screen_pos)
        if distance_px < nearest_screen:
            nearest_screen = distance_px
            nearest = i
    if nearest >= 0:
        selected_enemy = -1 if selected_enemy == nearest else nearest
        _notify("Ziel ausgewählt" if selected_enemy >= 0 else "Ziel aufgehoben")

func _open_dialog() -> void:
    if not game_running or shared_world:
        _notify("Weitere Abenteuer werden in späteren Versionen ergänzt.")
        return
    if hero.position.distance_to(npc.position) > 5:
        _notify("Seryn ist zu weit entfernt.")
        return
    var quests: Array[Dictionary] = DATA.quests_for(current_class)
    if quest_index >= quests.size():
        dialog_title.text = "Seryn · Abschluss"
        dialog_text.text = "Du hast alle drei Einführungsquests erfüllt. Die übrigen geplanten Startgebiets-Quests folgen später."
        dialog_accept.visible = false
    else:
        var q: Dictionary = quests[quest_index]
        dialog_title.text = str(q["title"])
        if not quest_accepted:
            dialog_text.text = DATA.REGION_INTROS[current_class] + "\n\n" + str(q["desc"])
            dialog_accept.text = "Quest annehmen"
        elif quest_progress >= int(q["count"]):
            dialog_text.text = "Sehr gut. Deine Aufgabe ist erfüllt.\nBelohnung: %d Erfahrungspunkte." % int(q["xp"])
            dialog_accept.text = "Quest abschließen"
        else:
            dialog_text.text = str(q["desc"]) + "\nFortschritt: %d/%d" % [quest_progress, int(q["count"])]
            dialog_accept.text = "In Ordnung"
        dialog_accept.visible = true
    dialogue_open = true
    dialog_panel.visible = true

func _accept_quest() -> void:
    var quests: Array[Dictionary] = DATA.quests_for(current_class)
    if quest_index >= quests.size():
        _close_dialog()
        return
    var q: Dictionary = quests[quest_index]
    if not quest_accepted:
        quest_accepted = true
        quest_progress = 0
    elif quest_progress >= int(q["count"]):
        _give_xp(int(q["xp"]))
        quest_index += 1
        quest_progress = 0
        quest_accepted = false
        _notify("Quest abgeschlossen!")
    _close_dialog()
    _save_game()

func _close_dialog() -> void:
    dialog_panel.visible = false
    dialogue_open = false

func _toggle_talents() -> void:
    if not game_running:
        return
    if dialogue_open:
        _close_dialog()
    var next_open := not talent_open
    _close_all_panels()
    talent_open = next_open
    talent_panel.visible = talent_open
    if talent_open:
        _refresh_talent_ui()

func _refresh_talent_ui() -> void:
    talent_text.text = "Talente · verfügbare Punkte: %d" % _talent_points()
    var names: Array = cfg()["talents"]
    for i in range(3):
        talent_buttons[i].text = str(names[i]) + "  [%d/3]  ·  +1 Rang" % talents[i]
        talent_buttons[i].disabled = talents[i] >= 3 or _talent_points() == 0

func _spend_talent(id: int) -> void:
    if _talent_points() < 1 or talents[id] >= 3:
        return
    talents[id] += 1
    _refresh_talent_ui()
    _save_game()

func _request_shared_world() -> void:
    if level < 10:
        _notify("Die gemeinsame Welt öffnet sich erst auf Stufe 10.")
        return
    shared_world = not shared_world
    _generate_zone()
    _save_game()
    _notify("Willkommen in den Kernlanden!" if shared_world else "Zurück in deinem Startgebiet.")

func _toggle_menu() -> void:
    if _any_panel_open():
        _close_all_panels()
        return
    if hp <= 0:
        hp = _max_hp()
        mana = 260
        hero.position = Vector3(0, _terrain_height(0.0, 3.0), 3.0)
        in_combat_timer = 0
        _notify("Du wurdest am Außenposten wiederbelebt.")
    else:
        _save_game()
        _toggle_options()

func _notify(text_value: String) -> void:
    if msg_label != null:
        msg_label.text = text_value
        message_timer = 3.1

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        _save_game()
