# PALAGOS v0.9.3 – Echte texturierte Charaktermodelle (Testversion)

Diese Version nutzt die vom Nutzer bereitgestellten **Quaternius RPG Characters 2020** (CC0).

## Neu
- GLTF-Charaktere mit Texturen und Skelettanimationen statt Kugel-/Kapselkörpern bei Spielfiguren und in der Klassenauswahl
- 6 Klassen: Krieger = Warrior_Brown (braune Rüstung), Jäger = Ranger, Magier = Wizard, Priester = Cleric, Druide = Monk, Paladin = Warrior_Gold (goldgelbe Rüstung, noch dasselbe Grund-Rig)
- Importierte Idle-, Run-, Sword_Attack-, Spell1-, Bow_Draw-/Bow_Shoot-Animationen an die bestehende Spiellogik gekoppelt
- NPC/Händler sind weiterhin die bisherigen Platzhalter
- Bestehende Klassen, Kamerasteuerung, Quests, Inventar, Waffen- und Mana-Logik erhalten

## Noch nicht fertig
- Paladin hat noch kein eigenständiges Modell, aber eine eigene goldgelbe Textur; Krieger trägt die braune Variante
- Geschlechts-, Gesichts- und Haarfarbwahl ändern die neuen, bereits texturierten GLTF-Modelle noch nicht sichtbar
- Ausrüstungswechsel aktualisiert die Werte, aber der neue importierte Modellwaffen-Look ist noch nicht dynamisch wechselbar
- Die Grafik wurde noch nicht auf einem realen Android-Gerät getestet
- Quaternius-Modelle sind stilisiert und nicht fotorealistisch

## Tests
Die Python-Quelltests prüfen die Projektstruktur und eingebettete GLTF-Modelle. Der Godot-Headless-Test auf GitHub muss die Szene, AnimationPlayer und sechs Klassen laden, bevor eine APK als Artefakt freigegeben wird.

Lizenz: `models/quaternius/LICENSE_CC0.txt`.

## Klassenfarben
Krieger: braunes Leder mit gedämpften dunkelbraunen Metallteilen. Paladin: leuchtend goldene Rüstung und goldgelbe Kleidungsflächen. Die originalen Hautbereiche, Skelette und Animationen bleiben unverändert. Die Texturvarianten sind als eigenständige glTF-Dateien eingebettet.
