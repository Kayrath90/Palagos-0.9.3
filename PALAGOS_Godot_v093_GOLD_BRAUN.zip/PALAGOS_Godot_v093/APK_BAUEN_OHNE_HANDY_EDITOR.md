# Palagos als normale Android-App testen

Dieses Paket ist ein **Godot 4.7.2-Projekt**, noch **KEINE APK**.

### Ohne Entwicklungsprogramme auf deinem Handy

Die enthaltene Datei `.github/workflows/android-debug-apk.yml` ist ein vorbereiteter GitHub-Actions-Build.
Dafür werden **ein GitHub-Konto, ein Repository und einmaliges Hochladen der entpackten Projektdateien** benötigt. Die kostenlose Nutzung hängt von den jeweils geltenden GitHub-Actions-Kontingenten ab.

1. Lade den Projektinhalt in den Hauptordner eines GitHub-Repositories hoch (inkl. versteckter `.github`-Ordner).
2. Gehe zu **Actions → Palagos Android APK (Godot 4.7.2) → Run workflow**.
3. Nach einem erfolgreichen Lauf: **Artifacts → Palagos-v07-Android** herunterladen und entpacken.
4. Die erhaltene `.apk` am Android-Handy öffnen und installieren. Falls nötig Androids Hinweis zum Installieren aus dieser Quelle bestätigen.

Der GitHub-Workflow ist **vorbereitet, aber in dieser Umgebung nicht ausgeführt oder validiert**. Er kann bei geänderten Godot-Exportoptionen oder externen Downloads scheitern.

### Alternativer Build am PC

Godot **4.7.2** plus passende Android-Exporttemplates und Android-SDK einrichten, `project.godot` öffnen, unter Projekt → Export `Android` wählen und eine Debug-APK exportieren.

**Status:** Kein Godot-Editor/Android-SDK in der aktuellen Arbeitsumgebung; keine laufzeitgeprüfte APK. Godot-Laufzeitprüfung und Test auf realem Gerät stehen aus.
