from pathlib import Path
import re, unittest, ast
ROOT = Path(__file__).resolve().parents[1]
GAME=(ROOT/'scripts/main.gd').read_text()
ITEM=(ROOT/'scripts/item_data.gd').read_text()
DATA=(ROOT/'scripts/game_data.gd').read_text()

class TestPalagos(unittest.TestCase):
    def test_files(self):
        for rel in ['project.godot','export_presets.cfg','scenes/Main.tscn', 'audio/Legends_of_the_Enchanted_Realm.mp3']:
            self.assertTrue((ROOT/rel).is_file(),rel)
        self.assertGreater((ROOT/'audio/Legends_of_the_Enchanted_Realm.mp3').stat().st_size, 1000000)
    def test_character_creation(self):
        for s in ['_show_title','_show_creator','_setup_preview_scene','_change_gender','_change_face','_change_hair','_start_chosen_game']:
            self.assertIn('func '+s+'(', GAME)
        self.assertEqual(DATA.count('"region":'),6)
    def test_inventory_equipment(self):
        self.assertIn('const BAG_SIZE = 24',ITEM)
        for item in ['weapon','head','chest','hands','legs','feet','trinket']:
            self.assertIn('"'+item+'"', ITEM)
        for method in ['_add_item','_bag_has_room','_equip_bag_slot','_unequip_item','_buy_item','_sell_item','_refresh_inventory','_refresh_gear','_refresh_shop','_save_game','_restore_progress']:
            self.assertIn('func '+method+'(', GAME)
        for word in ['"gold":gold','"bag":bag','"gear":gear','"appearance":appearance']:
            self.assertIn(word,GAME)
    def test_music(self):
        for method in ['_setup_music','_restart_music','_set_music_volume','_set_music_muted','_save_audio_settings']:
            self.assertIn('func '+method+'(', GAME)
        self.assertIn('Legends_of_the_Enchanted_Realm.mp3', GAME)
    def test_gameplay(self):
        self.assertIn('clampi(int(save.get("level", 1)), 1, 20)',GAME)
        self.assertIn('while level < 20',GAME)
        self.assertIn('"Kernbrut", "Bohrling", "Verderbter Waldjäger"',GAME)
        self.assertNotIn('PrimitiveMesh3D',GAME)
        self.assertIn('textures/vram_compression/import_etc2_astc=true',(ROOT/'project.godot').read_text())
    def test_uniqueness(self):
        methods = re.findall(r'^func ([\w]+)\(',GAME,re.M)
        self.assertEqual(len(methods),len(set(methods)), 'Duplicate GDScript functions')
        assert 'func _setup_dialogs(' in GAME
        self.assertIn('func _setup_selection(',GAME)
        self.assertIn('func _show_title(',GAME)
if __name__=='__main__':unittest.main()
