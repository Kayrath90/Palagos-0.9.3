"""Offline checks; actual GLTF import and rendering are tested in Godot CI."""
import unittest
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=(ROOT/'scripts/main.gd').read_text()
class ImportedModels(unittest.TestCase):
 def test_six_classes_have_model_mappings(self):
  for k in ('krieger','jaeger','magier','priester','druide','paladin'):
   self.assertIn('"'+k+'":',SCRIPT)
 def test_model_assets_are_embedded_glTF_with_animations(self):
  for name in ('Warrior','Ranger','Wizard','Cleric','Monk','Rogue'):
   doc=json.loads((ROOT/'models/quaternius'/f'{name}.gltf').read_text())
   self.assertGreater(len(doc['skins']),0)
   self.assertGreater(len(doc['animations']),7)
   self.assertTrue(doc['buffers'][0]['uri'].startswith('data:application/octet-stream;base64,'))
 def test_avatar_replaces_procedural_when_imported(self):
  self.assertIn('if _import_quaternius_avatar(root, tag):',SCRIPT)
  self.assertIn('_update_imported_avatar_animation()',SCRIPT)
  self.assertIn('imported_preview_animation',SCRIPT)
 def test_godot_smoke_exists(self):
  self.assertIn('PALAGOS_093_MODELS_PASS',(ROOT/'tests/smoke_models.gd').read_text())
 def test_original_assets_licensed_cc0(self):
  self.assertIn('CC0 1.0',(ROOT/'models/quaternius/LICENSE_CC0.txt').read_text())
if __name__=='__main__': unittest.main()
