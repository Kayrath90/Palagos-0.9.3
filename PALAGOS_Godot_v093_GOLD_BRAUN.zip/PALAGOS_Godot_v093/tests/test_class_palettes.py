"""Checks for independently coloured Warrior and Paladin, preserving skeletons."""
import base64
import json
import re
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MODEL=ROOT/'models/quaternius'
SOURCE=(ROOT/'scripts/main.gd').read_text(encoding='utf-8')

class ClassColorTests(unittest.TestCase):
    def get_data(self,name):
        return json.loads((MODEL/(name+'.gltf')).read_text())

    def get_texture(self,doc):
        view=doc['bufferViews'][doc['images'][0]['bufferView']]
        data=base64.b64decode(doc['buffers'][0]['uri'].split(',',1)[1])
        self.assertEqual(len(data),doc['buffers'][0]['byteLength'])
        offset=view['byteOffset']; length=view['byteLength']
        self.assertLessEqual(offset+length,len(data))
        png=data[offset:offset+length]
        self.assertEqual(png[:8],b'\x89PNG\r\n\x1a\n')
        return png

    def test_distinct_class_files(self):
        self.assertRegex(SOURCE,r'"krieger": "Warrior_Brown"')
        self.assertRegex(SOURCE,r'"paladin": "Warrior_Gold"')
        self.assertIn('var chosen := current_class if tag == "hero" else chosen_class',SOURCE)

    def test_rig_and_animations_remain_identical(self):
        original=self.get_data('Warrior')
        for variant in ('Warrior_Brown','Warrior_Gold'):
            modified=self.get_data(variant)
            for component in ('meshes','skins','animations','nodes','scenes','accessors'):
                self.assertEqual(original[component],modified[component], f'{variant}: {component} must not change')
            self.assertEqual(len(modified['animations']),len(original['animations']))

    def test_both_palettes_are_different_and_valid(self):
        original=self.get_texture(self.get_data('Warrior'))
        brown=self.get_texture(self.get_data('Warrior_Brown'))
        gold=self.get_texture(self.get_data('Warrior_Gold'))
        self.assertNotEqual(original,brown)
        self.assertNotEqual(original,gold)
        self.assertNotEqual(brown,gold)
        for name in ('Warrior_Brown','Warrior_Gold'):
            doc=self.get_data(name)
            self.assertEqual(len(doc['images']),2)
            self.assertEqual(len(doc['materials']),2)

if __name__=='__main__': unittest.main()
