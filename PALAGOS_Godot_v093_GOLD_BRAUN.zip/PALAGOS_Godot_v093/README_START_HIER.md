# PALAGOS v0.9 – Grafikversion

Die neueste Anleitung steht in `README_V09.md`.

# Palagos 0.8 – Systeme vor Weltgröße (Godot 4.7.2)

Dieses Paket ist ein **weiterentwickelbares Godot-Projekt**. Es enthält noch keine APK. Für Android ist der separate GitHub-Actions-Build vorgesehen.

## Was diese Testversion implementiert

- Titelbildschirm **PALAGOS – Das Herz der Finsternis**, „Spiel starten“, Optionsmenü.
- Deine Datei **Legends of the Enchanted Realm.mp3** ist eingebunden: läuft über Titelbildschirm und Spielwelt, wiederholt sich, Lautstärke 0–100 % und Stummschaltung. Musik-Einstellungen werden im Benutzerprofil lokal gespeichert.
- Charaktererstellung mit **sechs Klassen**, Live-3D-Vorschau, männlich/weiblich, vier Gesichtsvarianten und vier Haarfarben. Die einfachen Figurenmodelle bleiben **vorläufige Platzhalter**.
- **Inventar mit 24 Slots**, Stapeln von Tränken und Materialien; Gegenstand antippen für Details und danach ausdrücklich Ausrüsten/Benutzen.
- **Ausrüstung mit sieben Slots** (Waffe, Kopf, Brust, Hände, Beine, Füße, Amulett), Klassenbeschränkungen bei Waffen und Anzeige von Angriffs- und Lebensboni.
- **Drei Händler**: Waffen, Rüstung, Verbrauchsmaterial. Gold, Kaufen und Verkaufen.
- **Drei Gegnertypen** mit unterschiedlichen Lebenspunkten, Angriffswerten, Geschwindigkeit und Modellen; Erfahrung, Gold und Beute bei Sieg.
- Alle sechs bekannten Kampfstile mit Castzeiten, Mana und Talenten aus dem Godot-0.7-Prototyp.
- **Levelmaximum 20**. Bisher existieren weiterhin nur **drei Einführungsquests pro Klasse**. Die geplanten ~50 individuellen Startgebietsquests samt Abschlussbuffs sind noch **nicht umgesetzt**.
- Alte Godot-Speicherstände der früheren `v06`/`v07`-Serie werden pro Klasse weiterhin gelesen. Neue Daten (Inventar, Ausrüstung, Erscheinungsbild) werden in derselben Speicherdatei ergänzt.

## Bedienung

Nach App-Start auf **Spiel starten** tippen, Klasse wählen, Erscheinungsbild einstellen, **Abenteuer beginnen**. Im Spiel:

- **Tasche**: Inventar, Gegenstand wählen, Werte lesen und danach Ausrüsten/Benutzen.
- **Ausrüstung**: Anzeigen/Ablegen durch Tippen.
- **Optionen**: Lautstärke anpassen oder stumm.
- Händler **Rovik**, **Maera**, **Tessa** nahe Seryn ansprechen, kaufen oder Gegenstände verkaufen.
- Steuerung: Links Joystick, rechts wischen = Kamera; Ziele/NPCs tippen; drei Kampfbuttons unten rechts.

## Einschränkungen / wichtiger Testhinweis

Dieses Projekt wurde in einer Entwicklungsumgebung ohne Godot-Binärdatei erstellt. Dateistruktur, Inhalte und mehrere Konsistenztests können geprüft werden; **ein echter Godot-Laufzeit- und Android-Gerätetest steht noch aus**. Der beiliegende GitHub-Workflow führt beim ersten Build eine zusätzliche `--headless` Skript- und Startdiagnose aus. Sollte die Diagnose fehlschlagen, wird **keine APK als fertig markiert**. Bitte das Build-Log zur Analyse zurücksenden.

Diese Version ist **kein fertiges RPG**: Karte, Dorfmodelle, Quests und Figuren sind technische Prototypen. Verbesserte Grafik und umfangreiche Gebiete werden erst nach der Prüfung der Kernsysteme entwickelt.
