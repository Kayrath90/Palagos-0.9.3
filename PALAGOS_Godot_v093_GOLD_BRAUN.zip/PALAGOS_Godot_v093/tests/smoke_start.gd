extends SceneTree

# Executed headlessly in GitHub Actions: instantiate the real game UI,
# open character selection, check the preview and camera, and start gameplay.
func _initialize() -> void:
    call_deferred("_run_smoke")

func _run_smoke() -> void:
    var packed := load("res://scenes/Main.tscn") as PackedScene
    if packed == null:
        push_error("SMOKE: Could not load Palagos main scene")
        quit(1)
        return
    var game := packed.instantiate()
    root.add_child(game)
    await process_frame
    if not is_instance_valid(game) or not is_instance_valid(game.get("title_screen")):
        push_error("SMOKE: Title menu missing")
        quit(1)
        return
    game.call("_show_creator")
    await process_frame
    var picture := game.get("preview_container") as SubViewportContainer
    var viewport := game.get("creator_preview") as SubViewport
    if picture == null or viewport == null or viewport.get_parent() != picture or not picture.visible:
        push_error("SMOKE: 3D character preview texture missing")
        quit(1)
        return
    game.set("camera_yaw", 0.0)
    game.call("_apply_camera_drag", Vector2(100.0, -60.0))
    if float(game.get("camera_yaw")) >= 0.0:
        push_error("SMOKE: Horizontal camera direction inverted")
        quit(1)
        return
    if float(game.get("camera_pitch")) <= -0.18:
        push_error("SMOKE: Vertical camera direction inverted")
        quit(1)
        return
    # Verify that this is a real rendering viewport with a camera and a model.
    if not viewport.get_camera_3d() or viewport.find_child("preview", true, false) == null:
        push_error("SMOKE: Preview scene missing 3D camera or character")
        quit(1)
        return
    game.call("_choose_class", "magier")
    game.call("_start_chosen_game")
    await process_frame
    if not bool(game.get("game_running")) or not is_instance_valid(game.get("active_zone")):
        push_error("SMOKE: Gameworld did not start")
        quit(1)
        return
    var hero := game.get("hero") as CharacterBody3D
    if hero == null or hero.get_child_count() == 0:
        push_error("SMOKE: Player physics body is absent")
        quit(1)
        return
    var enemies: Array = game.get("enemies")
    if enemies.size() < 6:
        push_error("SMOKE: Enemies missing")
        quit(1)
        return
    print("PALAGOS_09_SMOKE_PASS: title, preview, camera, gameworld, enemies")
    quit(0)
