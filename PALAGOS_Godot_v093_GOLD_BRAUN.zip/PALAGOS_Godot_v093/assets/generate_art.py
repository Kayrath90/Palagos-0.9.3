from PIL import Image,ImageDraw,ImageFilter
import numpy as np,random, math
from pathlib import Path
random.seed(45)
out=Path('/mnt/data/palagos09_work/PALAGOS_Godot_v09/assets')
out.mkdir(parents=True,exist_ok=True)

def tex(filename,base,amp,lines=0,speck=0):
    n=256; rng=np.random.default_rng(42+len(filename))
    coarse=rng.normal(0,1,(16,16)); mid=rng.normal(0,1,(64,64)); fine=rng.normal(0,1,(n,n))
    def up(a):return np.array(Image.fromarray(((a+3)*35).clip(0,255).astype('uint8')).resize((n,n),Image.Resampling.BICUBIC)).astype(float)/35-3
    noise=up(coarse)*.65+up(mid)*.24+fine*.12
    arr=np.zeros((n,n,3),dtype=np.uint8)
    for j in range(3): arr[:,:,j]=np.clip(base[j]+noise*amp[j],0,255).astype('uint8')
    img=Image.fromarray(arr,'RGB');d=ImageDraw.Draw(img,'RGBA')
    if lines:
        for y in range(0,256,lines):
            d.line((0,y,256,y),fill=(27,27,25,80),width=2)
            for x in range(-20+(y%31),270,52):
                d.line((x,y,x,y+lines),fill=(25,25,23,65),width=2)
    for i in range(speck):
        x=random.randrange(n);y=random.randrange(n);r=random.choice([1,1,2,3]);
        d.ellipse((x-r,y-r,x+r,y+r),fill=(24,21,15,random.randrange(25,90)))
    img.save(out/filename,optimize=True)
tex('terrain_grass.png',(188,197,175),(34,32,28),0,900)
tex('terrain_path.png',(189,169,133),(25,26,24),0,2200)
tex('rock_moss.png',(178,179,169),(34,34,31),0,1500)
tex('bark_worn.png',(144,111,78),(32,27,23),13,160)
tex('leaf_cluster.png',(181,203,160),(35,38,32),0,900)
tex('village_plaster.png',(194,183,155),(29,24,21),42,260)
tex('roof_shingles.png',(192,164,149),(28,30,24),18,320)
# The title's 2D painted backdrop is a local procedural asset, not third-party art.
w,h=1600,900
Y,X=np.mgrid[0:h,0:w].astype(float)
color=np.zeros((h,w,3),dtype=np.float32)
t=(Y/h)
for i,(top,bot) in enumerate(zip((12,24,42),(109,94,92))):
    color[:,:,i]=top*(1-t)+bot*t
# distant sun and corrupted violet light
for center,radius,c,bright in [((1235,335),450,(143,65,81),0.53),((1100,520),230,(230,131,89),0.26),((260,80),600,(45,74,106),0.25)]:
    dd=((X-center[0])**2+(Y-center[1])**2)/radius**2
    halo=np.exp(-dd*3)*bright
    for i in range(3):color[:,:,i]=color[:,:,i]*(1-halo)+c[i]*halo
rng=np.random.default_rng(11)
color+=(rng.normal(0,2.9,(h,w)))[:,:,None]
img=Image.fromarray(np.uint8(color.clip(0,255)),'RGB').convert('RGBA')
glow=Image.new('RGBA',(w,h));g=ImageDraw.Draw(glow,'RGBA')
for j in range(14):
    r=16+j*11; alpha=int(26*(1-j/15))
    g.ellipse((1235-r,335-r,1235+r,335+r),fill=(240,127,101,alpha))
glow=glow.filter(ImageFilter.GaussianBlur(18));img=Image.alpha_composite(img,glow)
d=ImageDraw.Draw(img,'RGBA')
# distant mountains and forest foothills
for layer,base_y,amp,c in [(0,650,102,(27,42,50,255)),(1,720,78,(19,32,38,255)),(2,801,61,(12,24,32,255))]:
    pts=[(0,h)]
    for x in range(0,w+14,13):
        mountain=base_y+ math.sin(x*.008+layer*1.7)*amp*.6+math.sin(x*.019+layer)*amp*.3+math.sin(x*.036+3)*amp*.08
        pts.append((x,mountain))
    pts += [(w,h)]
    d.polygon(pts,fill=c)
# thin streaks and bore rig on right
p=[(1241,452),(1282,452),(1274,724),(1249,737)];d.polygon(p,fill=(53,44,49,255))
for height in [470,524,578,632,685]:
    d.line((1205,height,1310,height-8),fill=(105,64,65,255),width=7)
for x in [1204,1311]:
    d.line((x,465,x+5,754),fill=(23,20,25,255),width=16)
d.line((1186,453,1327,441),fill=(57,41,45,255),width=14)
# red veins in near mountain
for i in range(7):
    x=1180+i*24;y=753+i*14
    d.line([(x,y),(x+random.randint(-24,35),y+28),(x+random.randint(-20,52),y+58)],fill=(218,98,64,130),width=random.randint(2,5),joint='curve')
# tree silhouettes at sides
for side in [0,1]:
    for i in range(24):
        x=random.randint(0,330) if side==0 else random.randint(1400,1600)
        y=random.randint(710,895)
        ht=random.randint(40,180);width=ht*.27
        d.line((x,y,x,y-ht),fill=(10,24,28,245),width=max(2,int(ht*.034)))
        for k in range(5):
            yy=y-ht+ k*ht/5
            ww=width*(k+2)/7
            d.polygon([(x,yy-ht*.1),(x-ww,yy+ht*.15),(x+ww,yy+ht*.15)],fill=(9,26,28,250))
img.convert('RGB').save(out/'title_palagos.png',quality=91,optimize=True)
print('Created',[(p.name,p.stat().st_size) for p in out.glob('*.png')]);
