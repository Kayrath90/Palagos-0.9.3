# Palagos – Welt- und Questplan (noch nicht implementiert)

- Klasse Krieger: Startregion Eisenklamm (Level 1–10)
- Klasse Jäger: Startregion Grünwald (Level 1–10)
- Klasse Magier: Startregion Astralhain (Level 1–10)
- Klasse Priester: Startregion Lichtwacht (Level 1–10)
- Klasse Druide: Startregion Wurzelmeer (Level 1–10)
- Klasse Paladin: Startregion Sonnenfeste (Level 1–10)

In jeder Region ist ein größeres Dorf mit eigener visueller Kultur, Händlern und ungefähr 40–50 Quests geplant. Die letzte Klassenquest belohnt mit einem klassenweiten, zehnminütigen Gruppenbuff:

| Klasse | Arbeitstitel | Effekt |
|---|---|---|
| Jäger | Segen des Pfadfinders | +15 % Laufgeschwindigkeit außerhalb, +5 % im Kampf |
| Magier | Sternenresonanz | +10 % Intelligenz |
| Krieger | Eid der Eisenklamm | +10 % Stärke |
| Paladin | Herz der Sonnenfeste | +10 % maximale Lebenspunkte |
| Druide | Dornenbund | 10 % des erlittenen Nahkampfschadens reflektieren |
| Priester | Quell der Morgenwacht | +1 HP/s und +0,5 Mana/s im Kampf |

Spieler mit derselben Klasse starten zusammen. Freunde verschiedener Klassen dürfen zu den Startgebieten des jeweils anderen reisen. Ab Stufe 10 führt der Weg zu gemeinsamen Zonen bis zur vorläufigen Höchststufe 20.

Die Welt ist ein erdähnlicher Planet, dessen Kern von außerirdischen dämonischen Invasoren mittels gigantischer Bohranlagen angegriffen wird. Bohrstellen eignen sich später für Dungeons und Raids. Ziel ist langfristig ein kleines Online-RPG für Freunde und überschaubare Spielergruppen, nicht ein massenhaftes MMORPG.

## Aktueller Stand in 0.8

**Nur drei Einführungsquests pro Klasse und ein kleines gemeinsames Testgebiet existieren.** Die oben skizzierten großen Gebiete, Level-10-Gruppenbuffs, Klassenabschlussquests, Koopserver und Questreihen werden in späteren Schritten entwickelt. Version 0.8 konzentriert sich auf Hauptmenü, Charaktererstellung, Musik, Inventar, Ausrüstung, Shops und persistente Daten.
