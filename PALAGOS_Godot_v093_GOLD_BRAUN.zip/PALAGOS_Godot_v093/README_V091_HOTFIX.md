# Palagos 0.9.1 – Stabilitäts-Update / Android

**Änderungen:** Korrigierte horizontale Kameradrehung; 3D-Vorschau über SubViewportContainer statt indirektem Texturverweis; Charakter ist jetzt CharacterBody3D mit CapsuleShape3D; Häuser, Baumstämme, Felsen haben echte Kollisionen; Kamera-Raycast gegen Wände.

**Grafische Einschränkung:** Prozedural erzeugte Charaktermodelle sind weiterhin Platzhalter. Für glaubwürdige, animierte Figuren sollen CC0 glTF-Modelle mit Skelett/Animationsbibliothek importiert werden. Kein neues AAA-Modell vorgetäuscht.

**Tests:** Die Python-Strukturtests testen kein echtes Renderbild. Die Godot-Headless-Prüfung erkennt Skript- und Szenenfehler, aber keinen schwarzen Android-Viewport. Test der Vorschau und Kollision unbedingt am Smartphone durchführen. 

**Einsatz:** ZIP als neues Projekt-Archiv in GitHub hochladen, Build-Konfiguration `PALAGOS_GitHub_Android_v091.yml` separat als `.github/workflows/android.yml` speichern. Alte APK behalten bis die neue auf dem Telefon geprüft wurde.

**Lizenzhinweis:** Eigene Projektdateien enthalten keine neu heruntergeladenen Fremdmodelle. Die Musikrechte sind vor einer kommerziellen Veröffentlichung zu prüfen.
