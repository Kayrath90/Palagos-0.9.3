# PALAGOS 0.9 – Grafik und Kamera

Dies ist die erste **Grafik-Aufbaustufe** auf Basis der funktionierenden Godot-0.8-Version.
Bitte realistische Erwartungen: organischer und atmosphärischer, aber **noch keine extern geriggten High-End-3D-Modelle**.

## Umgesetzt

- Neue Grafik für das Titelmenü, aus eigenen programmatisch erzeugten Bilddaten (keine gekauften Assets)
- Kreator-3D-Vorschau über `SubViewportTexture` direkt als `TextureRect`; langsam rotierendes Modell
- Sechs unterscheidbare Fantasy-Klassenmodelle mit schmaleren Proportionen, mehr Gesichtsdetails und charakteristischen Verzierungen
- Größeres unebenes Gelände (184 × 184 Meter statt 100 × 100 Meter), geglättete Normalen
- Mehrere neue Texturen für Erde, Gras, Baumrinde, Laub, Fels, Häuser und Dächer
- Gras und Wald per MultiMesh-Instancing, damit viele Objekte nicht tausende Renderaufrufe verursachen
- Geschwungene Feldwege, Dorfhäuser mit Schrägdächern, Fenster, Zäune und Laternen
- Klassenspezifische Wahrzeichen, mehr Kristalle und verschiedenartige Dämonen
- Kamerarichtung korrigiert: Wischbewegung nach rechts lässt die Blickrichtung nach rechts drehen; aufwärts blickt nach oben
- Zusätzliche Schalter, um die horizontale oder vertikale Achse bei Bedarf umzukehren; gespeichert lokal
- Bestehende Systeme aus v0.8 (Kampf, Händler, Inventar, Ausrüstung, Musik) erhalten

## Einschränkungen

Godot selbst ist in dieser Chat-Arbeitsumgebung **nicht ausführbar**. Das Projekt hat zwölf statische und Konsistenztests bestanden.
Das beiliegende GitHub-Workflow-Skript führt danach mit Godot 4.7.2 zusätzlich
Skriptimport- und Startprüfungen durch. Die tatsächlich gerenderte Android-Grafik,
3D-Vorschau sowie Touch-Steuerung müssen abschließend auf dem Samsung getestet werden.

## So baust du die APK

Im bestehenden GitHub-Repository **Palagos-0.8** (ein neues Repository ist nicht nötig):

1. `PALAGOS_Godot_v09_GRAFIK.zip` als neue Datei hochladen (gepackt lassen).
2. `.github/workflows/android.yml` öffnen und den Inhalt vollständig durch `PALAGOS_GitHub_Android_v09.yml` ersetzen.
3. Änderungen mit `Commit changes` speichern.
4. Unter Actions den **letzten** Build öffnen. Nur bei grünem Haken das Artifact
   `Palagos-0.9-Android-Grafiktest` herunterladen.
5. Auf dem Handy die APK aus dem heruntergeladenen Artifact-ZIP entpacken und installieren.

Die v0.9-APK verwendet bewusst eine eigene Android-Paketkennung (`org.palagos.prototype.v09`) und wird **neben** v0.8 installiert, damit der bisherige, funktionierende Teststand erhalten bleibt.

Zum ersten Spieltest: Intro und Charaktervorschau ansehen, Magier auswählen,
Kamera rechts/links und auf/ab wischen, Bewegung testen, dann Wald und Dorf erkunden.
