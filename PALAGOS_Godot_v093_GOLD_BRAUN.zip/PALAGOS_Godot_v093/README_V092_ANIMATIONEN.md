# PALAGOS 0.9.2 – Kampf- & Waffenanimationen (experimenteller Android-Build)

Basierend auf Palagos 0.9.1. **Keine externen Premium-Assets:** Modelle werden weiterhin aus Godot-Meshes erzeugt. Für hochwertige geriggte Charaktere werden noch echte 3D-Assets benötigt.

## Neue Funktionen

- Sichtbare Klassenwaffen auch in der Charaktervorschau: **Schwert** (Krieger / Paladin), **Bogen mit Sehne** (Jäger), **Stab mit Kristall** (Magier / Priester / Druide).
- Der Jäger führt beim Grundangriff und Pfeilhagel ein sichtbares Anlegen und Spannen (0,78 s / 1,05 s) aus. Sehne und eingenockter Pfeil bewegen sich. Bei Loslassen fliegt ein 3D-Pfeil zum Ziel.
- Zauberklassen halten während der Wirkzeit ihre Arme hoch. Arkane Geschosse, Feuerbälle, Licht- und Naturgeschosse besitzen nun Flugbahnen, Lichtkerne und geringe Partikelspuren.
- Bei Geschossen entsteht Schaden **beim Einschlag**, nicht beim Abschuss. Die bestehenden Schadenszahlen und Mana-/Ausdauerkosten bleiben unverändert; Pfeile benötigen kurze Spannzeit.
- Schwertangriffe spielen eine Hiebbewegung der Waffe und des rechten Arms ab.
- Das Inventar steuert die sichtbare Waffe. Anlegen/Ablegen und das Laden eines Spielstandes aktualisieren das Waffenmodell.
- Kamerarichtung, Kollisionskorrekturen, 3D-Vorschau, Musik und übrige Systeme aus 0.9.1 bleiben im Quelltext erhalten.

## Aktueller Qualitätsstand

Dies ist **kein fertiges Motion-Capture- oder Skinning-System**. Armbewegung und Waffen sind noch prozedural animiert und **nicht** auf dem Qualitätsniveau eines professionellen Fantasy-RPGs. Die Godot-Runtime und Android-Grafik müssen erst über GitHub und auf einem echten Smartphone überprüft werden.

## Tests

- `python -m unittest discover -s PALAGOS_Godot_v092/tests -p 'test_*.py' -v`: statische Regressionen
- `godot --headless --path PALAGOS_Godot_v092 --script res://tests/smoke_start.gd`: bisheriger Starttest
- `godot --headless --path PALAGOS_Godot_v092 --script res://tests/smoke_animation.gd`: neuer Animationstest

## Installation

ZIP unverändert in das Repository hochladen, Workflow-Datei `.github/workflows/android.yml` auf v0.9.2 setzen. Nach **grünem** GitHub-Build unter Actions → Artifacts die Debug-APK herunterladen. Die Paketkennung ist `org.palagos.prototype.v092`, damit die ältere Version installiert bleiben kann.
