extends RefCounted
class_name PalagosItemData

const BAG_SIZE = 24
const EQUIPMENT_SLOTS = ["weapon", "head", "chest", "hands", "legs", "feet", "trinket"]
const SLOT_NAMES = {"weapon":"Waffe", "head":"Kopf", "chest":"Brust", "hands":"Hände", "legs":"Beine", "feet":"Füße", "trinket":"Amulett"}
const ITEMS = {
    "heal_small":{"name":"Kleiner Heiltrank", "type":"consumable", "price":16, "sell":5, "stack":20, "desc":"Stellt 45 Lebenspunkte wieder her."},
    "heal_large":{"name":"Heiltrank der Kernwacht", "type":"consumable", "price":43, "sell":14, "stack":10, "desc":"Stellt 95 Lebenspunkte wieder her."},
    "mana_draught":{"name":"Sternentau", "type":"consumable", "price":20, "sell":7, "stack":20, "desc":"Regeneriert sofort 65 Mana."},
    "wolf_fang":{"name":"Zahn eines Waldjägers", "type":"material", "price":0, "sell":5, "stack":20, "desc":"Ein Handwerksmaterial aus den Wäldern von Palagos."},
    "core_shard":{"name":"Verdorbener Kernsplitter", "type":"material", "price":0, "sell":12, "stack":20, "desc":"Ein Splitter aus einer dämonischen Bohrader."},
    "iron_sword":{"name":"Klinge der Grenzwacht", "type":"weapon", "slot":"weapon", "attack":6, "health":0, "price":82, "sell":23, "stack":1, "allowed":["krieger","paladin"], "desc":"Eine ausgewogene Einhandklinge."},
    "hunter_bow":{"name":"Grünwaldbogen", "type":"weapon", "slot":"weapon", "attack":6, "health":0, "price":82, "sell":23, "stack":1, "allowed":["jaeger"], "desc":"Aus dem Holz des Grünwalds gefertigt."},
    "star_staff":{"name":"Stab der Sternenlinie", "type":"weapon", "slot":"weapon", "attack":6, "health":0, "price":82, "sell":23, "stack":1, "allowed":["magier","priester","druide"], "desc":"Kanalisator für uralte Sternenströme."},
    "reinforced_chest":{"name":"Verstärkte Wanderweste", "type":"armor", "slot":"chest", "attack":0, "health":14, "price":76, "sell":20, "stack":1, "desc":"Schützt bei Streifzügen in die Wildnis."},
    "sturdy_hood":{"name":"Kapuze der Weitsicht", "type":"armor", "slot":"head", "attack":0, "health":8, "price":49, "sell":13, "stack":1, "desc":"Eine leichte, wetterfeste Kapuze."},
    "travel_gloves":{"name":"Handschuhe der Reisenden", "type":"armor", "slot":"hands", "attack":1, "health":4, "price":42, "sell":10, "stack":1, "desc":"Bewegliche Lederhandschuhe."},
    "path_leggings":{"name":"Beinschützer des Pfades", "type":"armor", "slot":"legs", "attack":0, "health":9, "price":52, "sell":13, "stack":1, "desc":"Widerstandsfähig und leicht."},
    "wander_boots":{"name":"Wanderstiefel", "type":"armor", "slot":"feet", "attack":0, "health":5, "price":38, "sell":9, "stack":1, "desc":"Stabile Stiefel für lange Reisen."},
    "sun_amulet":{"name":"Sonnenbernstein", "type":"trinket", "slot":"trinket", "attack":2, "health":6, "price":100, "sell":29, "stack":1, "desc":"Ein warmer, goldener Bernstein."}
}
const MERCHANTS = {
    "weapon":{"name":"Rovik · Waffenschmied", "items":["iron_sword", "hunter_bow", "star_staff", "travel_gloves"]},
    "armor":{"name":"Maera · Rüstmeisterin", "items":["reinforced_chest", "sturdy_hood", "path_leggings", "wander_boots", "sun_amulet"]},
    "supplies":{"name":"Tessa · Vorräte", "items":["heal_small", "heal_large", "mana_draught"]}
}

static func starter_weapon(class_id: String) -> String:
    if class_id == "jaeger":
        return "hunter_bow"
    if class_id in ["krieger", "paladin"]:
        return "iron_sword"
    return "star_staff"
