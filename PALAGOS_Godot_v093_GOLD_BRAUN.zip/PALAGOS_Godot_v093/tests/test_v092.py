"""Source-level regression tests supplement the Godot headless smoke test."""
from pathlib import Path
import re
import unittest

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'scripts/main.gd').read_text()
ITEMS=(ROOT/'scripts/item_data.gd').read_text()

class AnimatedCombatTests(unittest.TestCase):
    def test_weapon_mesh_for_every_equipped_class(self):
        for token in ('hunter_bow','iron_sword','star_staff'):
            self.assertIn(token,MAIN)
            self.assertIn(token,ITEMS)
        for name in ['_make_character_weapon','_refresh_visible_weapon','_animate_weapon_frame']:
            self.assertIn('func '+name+'(',MAIN)
    def test_bow_draw_string_and_release(self):
        for token in ['"NockedArrow"','weapon_string_upper','weapon_string_lower',
                      '"bow_draw"','"bow_release"', 'cast_remaining = 0.78',
                      '_position_rod(weapon_string_upper', '_launch_spell_missile(target']:
            self.assertIn(token,MAIN)
    def test_impact_handling_and_animated_spells(self):
        for token in ['"PalagosSpellProjectile"','"ArrowInFlight"','"trail_timer"',
                      '_update_missiles(delta)','_damage_near(goal, 4.8',
                      'node.look_at(goal, Vector3.UP)','"spell_channel"','"cast_release"']:
            self.assertIn(token,MAIN)
    def test_equipment_persists_and_refreshes(self):
        self.assertGreaterEqual(MAIN.count('_refresh_visible_weapon()'),3)
        self.assertIn('"gear":gear',MAIN)
    def test_unmodified_critical_fixes(self):
        for token in ['CharacterBody3D.new()', 'move_and_collide(travel)',
                      'SubViewportContainer.new()', 'camera_yaw += delta_motion.x * (0.006 if camera_invert_x else -0.006)']:
            self.assertIn(token,MAIN)
    def test_no_duplicate_functions(self):
        names=re.findall(r'^func (\w+)\(',MAIN,re.M)
        self.assertEqual(len(names),len(set(names)))

if __name__=='__main__': unittest.main()
