from pathlib import Path
import re, unittest
ROOT=Path(__file__).resolve().parents[1]
TEXT=(ROOT/'scripts/main.gd').read_text()
class PhysicsAndPreviewTests(unittest.TestCase):
    def test_camera_horizontal_direction(self):
        self.assertIn('camera_yaw += delta_motion.x * (0.006 if camera_invert_x else -0.006)',TEXT)
        self.assertIn('Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))',TEXT)
        # At yaw zero a negative yaw results in a +X (rightward) forward vector.
        import math
        self.assertGreater(-math.sin(-0.6),0)
    def test_preview_in_visible_ui(self):
        self.assertIn('SubViewportContainer.new()',TEXT)
        self.assertIn('preview_container.add_child(creator_preview)',TEXT)
        self.assertIn('cam.make_current()',TEXT)
        self.assertNotIn('preview_texture.texture',TEXT)
    def test_obstacle_physics(self):
        for needle in ['CharacterBody3D.new()', 'move_and_collide(travel)', 'StaticBody3D.new()', 'block.size = Vector3(4.65, 2.80, 4.55)', '_add_forest_collision(trunks, small_rocks)', 'intersect_ray(query)']:
            self.assertIn(needle,TEXT)
        self.assertIn('solid.collision_layer = 4',TEXT)
        self.assertIn('body.collision_mask = 4',TEXT)
    def test_no_duplicate_functions(self):
        functions = re.findall(r'^func (\w+)\(',TEXT,re.M)
        self.assertEqual(len(functions),len(set(functions)))
if __name__=='__main__':unittest.main()
