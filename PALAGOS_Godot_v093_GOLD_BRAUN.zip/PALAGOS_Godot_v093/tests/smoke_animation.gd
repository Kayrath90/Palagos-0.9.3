extends SceneTree

# Headless Godot 4.7.x runtime smoke test, separate from static source checks.
func _initialize() -> void:
    call_deferred("_run")

func _fail(reason: String) -> void:
    push_error("ANIMATION_SMOKE_FAIL: " + reason)
    quit(1)

func _run() -> void:
    var scene := load("res://scenes/Main.tscn") as PackedScene
    if scene == null:
        _fail("Main scene cannot load")
        return
    var game := scene.instantiate()
    root.add_child(game)
    await process_frame
    game.call("_show_creator")
    await process_frame
    var preview := game.get("creator_preview") as SubViewport
    if preview == null or preview.find_child("Quaternius_*", true, false) == null:
        _fail("Imported 3D preview model missing")
        return
    game.call("_choose_class", "magier")
    game.call("_start_chosen_game")
    await process_frame
    var hero := game.get("hero") as Node3D
    var anim: AnimationPlayer = game.get("imported_hero_animation") as AnimationPlayer
    if hero == null or hero.find_child("Quaternius_*", true, false) == null or anim == null:
        _fail("Mage imported model or animation not loaded")
        return
    game.call("_launch_spell_missile", 0, 11.0, 1)
    var flying: Array = game.get("missiles")
    if flying.is_empty():
        _fail("Fireball projectile did not spawn")
        return
    game.call("_start_game", "jaeger")
    await process_frame
    anim = game.get("imported_hero_animation") as AnimationPlayer
    if anim == null or not anim.has_animation("Bow_Draw"):
        _fail("Hunter imported bow draw clip missing")
        return
    var hunters: Array = game.get("enemies")
    var hunter_hero := game.get("hero") as Node3D
    hunters[0]["node"].position = hunter_hero.position + Vector3(0, 0, -6.0)
    game.set("selected_enemy", 0)
    game.call("_activate_slot", 0)
    if int(game.get("cast_slot")) != 0:
        _fail("Bow cast did not begin")
        return
    game.call("_update_imported_avatar_animation")
    if anim.current_animation != "Bow_Draw":
        _fail("Imported animation did not switch to Bow_Draw")
        return
    game.call("_update_combat", 0.9)
    if (game.get("missiles") as Array).is_empty():
        _fail("Bow did not fire a projectile")
        return
    print("PALAGOS_093_ANIMATION_PASS: real 3D, skeleton, spells, and bow draw")
    quit(0)
